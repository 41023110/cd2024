﻿# NX 1872
# Journal created by user on Fri May 17 09:40:31 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    scaleAboutPoint1 = NXOpen.Point3d(18.488805039354119, 29.333200302821417, 0.0)
    viewCenter1 = NXOpen.Point3d(-18.488805039354119, -29.333200302821417, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId1, "Create Sketch Dialog")
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    direction1 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XZ plane")
    datumCsys1 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point1 = datumCsys1.FindObject("POINT 1")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction1, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, True)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.Csystem = cartesianCoordinateSystem1
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane2.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    geom1[0] = datumPlane1
    plane2.SetGeometry(geom1)
    
    plane2.SetFlip(True)
    
    plane2.SetExpression(None)
    
    plane2.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane2.Evaluate()
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane3.SynchronizeToPlane(plane2)
    
    plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane3.SetGeometry(geom2)
    
    plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane3.Evaluate()
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject1 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject1
    feature1 = sketch1.Feature
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId4)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId3, None)
    
    theSession.SetUndoMarkName(markId1, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane3.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId6, "Create Rectangle")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId8, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(53.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(53.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(53.0, 0.0, 9.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(53.0, 0.0, 9.0)
    endPoint3 = NXOpen.Point3d(0.0, 0.0, 9.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 0.0, 9.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    geom3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom3.Geometry = line1
    geom3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateHorizontalConstraint(geom3)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line1
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys2 = workPart.Features.FindObject("SKETCH(1:1B)")
    point2 = datumCsys2.FindObject("POINT 1")
    geom2_5.Geometry = point2
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(26.5, 0.0, -9.6755466711095988)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression5 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(62.675546671109601, 0.0, 4.5)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression6 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension1 = dimension1
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension1)
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId9, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits3 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits7 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits11 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId10, None)
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point3 = workPart.Points.FindObject("ENTITY 2 4")
    assocOrigin1.PointOnGeometry = point3
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchLinearDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point4 = NXOpen.Point3d(30.435417526321377, 0.0, -6.3999709751610254)
    sketchLinearDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point4)
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchLinearDimensionBuilder1.Style.DimensionStyle.TextCentered = True
    
    dimensionlinearunits19 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits21 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits25 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits27 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId11, "Linear Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId11, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId9, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("50")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("50")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    nXObject2 = sketchLinearDimensionBuilder1.Commit()
    
    point1_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, NXOpen.View.Null, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(50.0, 0.0, 0.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line1, NXOpen.View.Null, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    theSession.SetUndoMarkName(markId12, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId12, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId9, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject3 = sketchLinearDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId14, None)
    
    theSession.SetUndoMarkName(markId9, "Linear Dimension")
    
    expression7 = sketchLinearDimensionBuilder1.Driving.ExpressionValue
    sketchLinearDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId13, None)
    
    theSession.SetUndoMarkVisibility(markId9, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId12, None)
    
    theSession.DeleteUndoMark(markId11, None)
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension2 = dimension2
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension2)
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId15, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits31 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits33 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits37 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits39 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits43 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits47 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId16, None)
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("2.8")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("2.8")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    nXObject4 = sketchLinearDimensionBuilder2.Commit()
    
    point1_3 = NXOpen.Point3d(50.0, 0.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(50.0, 0.0, 2.7999999999999998)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line2, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    theSession.SetUndoMarkName(markId17, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId17, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId15, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject5 = sketchLinearDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId19, None)
    
    theSession.SetUndoMarkName(markId15, "Linear Dimension")
    
    expression8 = sketchLinearDimensionBuilder2.Driving.ExpressionValue
    sketchLinearDimensionBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId18, None)
    
    theSession.SetUndoMarkVisibility(markId15, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId17, None)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch2 = theSession.ActiveSketch
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId21, "Extrude Dialog")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature1
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = curveFeatureRule1
    helpPoint1 = NXOpen.Point3d(38.359603084737493, 0.0, 3.5527136788005009e-15)
    section1.AddToSection(rules1, line1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId23, None)
    
    direction2 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction2
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId22, None)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("6")
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId24, None)
    
    theSession.SetUndoMarkName(markId21, "Extrude")
    
    expression11 = extrudeBuilder1.Limits.StartExtend.Value
    expression12 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression9)
    
    workPart.Expressions.Delete(expression10)
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId25, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder2.Destroy()
    
    section2.Destroy()
    
    workPart.Expressions.Delete(expression13)
    
    theSession.UndoToMark(markId25, None)
    
    theSession.DeleteUndoMark(markId25, None)
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects1 = [NXOpen.DisplayableObject.Null] * 5 
    objects1[0] = sketch2
    objects1[1] = line1
    objects1[2] = line2
    objects1[3] = line3
    objects1[4] = line4
    theSession.DisplayManager.BlankObjects(objects1)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin4, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId27, "Create Sketch Dialog")
    
    scaleAboutPoint2 = NXOpen.Point3d(21.048793429418517, -15.217708763160692, 0.0)
    viewCenter2 = NXOpen.Point3d(-21.048793429418517, 15.217708763160692, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(26.310991786773148, -19.02213595395088, 0.0)
    viewCenter3 = NXOpen.Point3d(-26.310991786773148, 19.02213595395088, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(32.88873973346643, -23.777669942438582, 0.0)
    viewCenter4 = NXOpen.Point3d(-32.88873973346643, 23.777669942438582, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(41.110924666833036, -29.722087428048248, 0.0)
    viewCenter5 = NXOpen.Point3d(-41.110924666833036, 29.722087428048248, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(51.388655833541286, -37.152609285060301, 0.0)
    viewCenter6 = NXOpen.Point3d(-51.388655833541286, 37.152609285060301, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(41.110924666833029, -29.722087428048244, 0.0)
    viewCenter7 = NXOpen.Point3d(-41.110924666833029, 29.722087428048244, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(32.888739733466444, -23.77766994243856, 0.0)
    viewCenter8 = NXOpen.Point3d(-32.888739733466409, 23.777669942438628, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(26.310991786773158, -19.022135953950851, 0.0)
    viewCenter9 = NXOpen.Point3d(-26.310991786773133, 19.022135953950933, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(18.488805039354123, -14.933265608709037, 0.0)
    viewCenter10 = NXOpen.Point3d(-18.488805039354091, 14.933265608709123, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(14.563489507922009, -11.94661248696722, 0.0)
    viewCenter11 = NXOpen.Point3d(-14.563489507921991, 11.946612486967306, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(11.28670436863956, -9.5572899895737624, 0.0)
    viewCenter12 = NXOpen.Point3d(-11.286704368639539, 9.5572899895738512, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(9.0293634949116406, -7.6458319916590085, 0.0)
    viewCenter13 = NXOpen.Point3d(-9.0293634949116228, 7.6458319916590849, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scalar1 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude1 = feature2
    edge1 = extrude1.FindObject("EDGE * 120 * 160 {(0,0,2.8)(25,0,2.8)(50,0,2.8) EXTRUDE(2)}")
    point5 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge2 = extrude1.FindObject("EDGE * 150 * 160 {(0,-6,2.8)(0,-3,2.8)(0,0,2.8) EXTRUDE(2)}")
    direction3 = workPart.Directions.CreateDirection(edge2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 160 {(25,-3,2.8) EXTRUDE(2)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction3, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem2
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin5, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane5.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom4 = [NXOpen.NXObject.Null] * 1 
    geom4[0] = face1
    plane5.SetGeometry(geom4)
    
    plane5.SetFlip(False)
    
    plane5.SetExpression(None)
    
    plane5.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane5.Evaluate()
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin6, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression17 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane6.SynchronizeToPlane(plane5)
    
    scalar2 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point6 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom5 = [NXOpen.NXObject.Null] * 1 
    geom5[0] = face1
    plane6.SetGeometry(geom5)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId28, None)
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject6 = sketchInPlaceBuilder2.Commit()
    
    sketch3 = nXObject6
    feature3 = sketch3.Feature
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId30)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId29, None)
    
    theSession.SetUndoMarkName(markId27, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point6)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression17)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression16)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane6.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint14 = NXOpen.Point3d(12.582854934844606, -22.602535716294891, 0.0)
    viewCenter14 = NXOpen.Point3d(-12.582854934844594, 22.60253571629498, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(10.066283947875689, -18.082028573035902, 0.0)
    viewCenter15 = NXOpen.Point3d(-10.066283947875675, 18.082028573035995, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(8.053027158300555, -14.465622858428715, 0.0)
    viewCenter16 = NXOpen.Point3d(-8.0530271583005337, 14.465622858428805, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-8.4705915294716743, -14.376144778892041, 0.0)
    viewCenter17 = NXOpen.Point3d(8.4705915294716956, 14.376144778892128, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-10.588239411839599, -17.970180973615062, 0.0)
    viewCenter18 = NXOpen.Point3d(10.588239411839616, 17.970180973615147, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-13.235299264799494, -22.46272621701883, 0.0)
    viewCenter19 = NXOpen.Point3d(13.235299264799515, 22.462726217018915, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-16.544124080999371, -28.078407771273547, 0.0)
    viewCenter20 = NXOpen.Point3d(16.544124080999392, 28.078407771273636, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-16.456743143951837, -38.301977405834791, 0.0)
    viewCenter21 = NXOpen.Point3d(16.456743143951865, 38.301977405834869, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-20.570928929939793, -47.877471757293492, 0.0)
    viewCenter22 = NXOpen.Point3d(20.570928929939821, 47.877471757293591, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(-25.713661162424739, -59.846839696616868, 0.0)
    viewCenter23 = NXOpen.Point3d(25.713661162424767, 59.846839696616954, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(-34.133178534192147, -78.506310628641913, 0.0)
    viewCenter24 = NXOpen.Point3d(34.133178534192176, 78.506310628641998, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(-27.306542827353702, -62.805048502913536, 0.0)
    viewCenter25 = NXOpen.Point3d(27.306542827353745, 62.805048502913621, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(-21.845234261882965, -50.426082421179828, 0.0)
    viewCenter26 = NXOpen.Point3d(21.845234261882993, 50.426082421179899, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(-23.665670450373213, -64.397930167842489, 0.0)
    viewCenter27 = NXOpen.Point3d(23.665670450373238, 64.397930167842546, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(-36.408723769804958, -93.866240969028397, 0.0)
    viewCenter28 = NXOpen.Point3d(36.408723769804986, 93.866240969028453, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-29.126979015843951, -75.092992775222712, 0.0)
    viewCenter29 = NXOpen.Point3d(29.126979015843993, 75.092992775222768, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(-23.301583212675162, -60.074394220178164, 0.0)
    viewCenter30 = NXOpen.Point3d(23.30158321267519, 60.074394220178206, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(-18.641266570140136, -48.059515376142535, 0.0)
    viewCenter31 = NXOpen.Point3d(18.641266570140154, 48.059515376142556, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(-14.91301325611211, -38.447612300914024, 0.0)
    viewCenter32 = NXOpen.Point3d(14.913013256112123, 38.447612300914059, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-11.37117260778548, -28.987169516567899, 0.0)
    viewCenter33 = NXOpen.Point3d(11.371172607785487, 28.987169516567935, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(-14.213965759731858, -36.233961895709882, 0.0)
    viewCenter34 = NXOpen.Point3d(14.213965759731863, 36.233961895709911, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(-17.184917619347942, -43.39919873360752, 0.0)
    viewCenter35 = NXOpen.Point3d(17.184917619347953, 43.399198733607527, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(-21.481147024184928, -54.24899841700941, 0.0)
    viewCenter36 = NXOpen.Point3d(21.481147024184938, 54.248998417009425, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(-17.294143790657358, -8.6470718953286614, 0.0)
    viewCenter37 = NXOpen.Point3d(17.294143790657376, 8.6470718953286969, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(-21.69699538878265, -17.381570891566206, 0.0)
    viewCenter38 = NXOpen.Point3d(21.69699538878265, 17.381570891566234, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(-27.121244235978303, -22.026645871208895, 0.0)
    viewCenter39 = NXOpen.Point3d(27.121244235978327, 22.026645871208917, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-33.901555294972887, -27.53330733901111, 0.0)
    viewCenter40 = NXOpen.Point3d(33.901555294972916, 27.533307339011152, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(-42.142817355629241, -34.65076093685073, 0.0)
    viewCenter41 = NXOpen.Point3d(42.142817355629312, 34.650760936850787, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(-46.825352617365809, -38.33825745546828, 0.0)
    viewCenter42 = NXOpen.Point3d(46.825352617365851, 38.33825745546833, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(-56.70257543509139, -47.556998752012191, 0.0)
    viewCenter43 = NXOpen.Point3d(56.702575435091511, 47.556998752012277, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(-96.028555172332233, -132.15358307049544, 0.0)
    viewCenter44 = NXOpen.Point3d(96.028555172332375, 132.15358307049553, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(-66.213975185493851, -100.96716658119514, 0.0)
    viewCenter45 = NXOpen.Point3d(66.213975185493965, 100.9671665811952, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(-52.971180148395071, -80.773733264956078, 0.0)
    viewCenter46 = NXOpen.Point3d(52.971180148395206, 80.773733264956121, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(-42.376944118716025, -64.6189866119649, 0.0)
    viewCenter47 = NXOpen.Point3d(42.376944118716132, 64.618986611964928, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(-33.901555294972823, -51.695189289571914, 0.0)
    viewCenter48 = NXOpen.Point3d(33.901555294972937, 51.695189289571942, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(-29.069178904860664, -38.958693377648387, 0.0)
    viewCenter49 = NXOpen.Point3d(29.06917890486077, 38.958693377648423, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(-23.495088929289434, -31.166954702118712, 0.0)
    viewCenter50 = NXOpen.Point3d(23.495088929289548, 31.166954702118737, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(-18.796071143431533, -24.933563761694955, 0.0)
    viewCenter51 = NXOpen.Point3d(18.796071143431654, 24.933563761694991, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(-15.036856914745231, -19.946851009355964, 0.0)
    viewCenter52 = NXOpen.Point3d(15.036856914745341, 19.946851009355999, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(-12.029485531796167, -15.957480807484767, 0.0)
    viewCenter53 = NXOpen.Point3d(12.029485531796269, 15.957480807484806, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint53, viewCenter53)
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId32, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(42.730170608830605, -3.0, 2.7999999999999998)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 2.0621975197364861, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = arc1
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 0.0
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(42.173446868969236, -3.0, 2.7999999999999998)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension3 = sketchDimensionalConstraint3.AssociatedDimension
    
    expression18 = sketchDimensionalConstraint3.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    scaleAboutPoint54 = NXOpen.Point3d(2.0621975197365505, -3.3387959843352544, 0.0)
    viewCenter54 = NXOpen.Point3d(-2.0621975197364502, 3.338795984335301, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(1.6497580157892466, -2.6710367874682004, 0.0)
    viewCenter55 = NXOpen.Point3d(-1.6497580157891569, 2.6710367874682439, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(1.4455022614534385, -2.0425575433580301, 0.0)
    viewCenter56 = NXOpen.Point3d(-1.4455022614533495, 2.0425575433580723, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(1.2569584882203857, -1.6089068649220131, 0.0)
    viewCenter57 = NXOpen.Point3d(-1.2569584882202987, 1.6089068649220568, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(1.5711981102754724, -2.0111335811525239, 0.0)
    viewCenter58 = NXOpen.Point3d(-1.5711981102753882, 2.0111335811525635, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(1.963997637844328, -2.5139169764406577, 0.0)
    viewCenter59 = NXOpen.Point3d(-1.9639976378442412, 2.5139169764407012, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(2.4549970473053944, -3.1423962205508258, 0.0)
    viewCenter60 = NXOpen.Point3d(-2.4549970473053246, 3.1423962205508724, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(-13.256984055448854, -6.6284920277244295, 0.0)
    viewCenter61 = NXOpen.Point3d(13.256984055448932, 6.628492027724473, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(-16.878104700224249, -8.3623336923838352, 0.0)
    viewCenter62 = NXOpen.Point3d(16.87810470022432, 8.3623336923838707, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(-21.097630875280327, -10.452917115479801, 0.0)
    viewCenter63 = NXOpen.Point3d(21.097630875280387, 10.452917115479838, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint63, viewCenter63)
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId33, "Curve")
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Curve Parameters")
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    associativeArcBuilder1 = workPart.BaseFeatures.CreateAssociativeArcBuilder(arc1)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("-3", unit1)
    
    scalar6 = workPart.Scalars.CreateScalarExpression(expression22, NXOpen.Scalar.DimensionalityType.Length, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("-42.7301706088306048", unit1)
    
    scalar7 = workPart.Scalars.CreateScalarExpression(expression23, NXOpen.Scalar.DimensionalityType.Length, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("2.13782471478366795e-16", unit1)
    
    scalar8 = workPart.Scalars.CreateScalarExpression(expression24, NXOpen.Scalar.DimensionalityType.Length, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin8 = NXOpen.Point3d(8.8498061145931633e-17, 0.0, 2.799999999999994)
    xDirection2 = NXOpen.Vector3d(0.0, 1.0, -0.0)
    yDirection2 = NXOpen.Vector3d(-1.0, 0.0, -1.3010426069826053e-16)
    xform4 = workPart.Xforms.CreateXform(origin8, xDirection2, yDirection2, NXOpen.SmartObject.UpdateOption.WithinModeling, 1.0)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point7 = workPart.Points.CreatePoint(cartesianCoordinateSystem4, scalar6, scalar7, scalar8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates2 = NXOpen.Point3d(42.730170608830605, -0.93780248026351387, 2.7999999999999998)
    point8 = workPart.Points.CreatePoint(coordinates2)
    
    origin9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin9, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression26 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    associativeArcBuilder1.Limits.StartLimit.Distance.SetFormula("0")
    
    associativeArcBuilder1.Limits.StartLimit.Distance.SetFormula("0")
    
    theSession.SetUndoMarkName(markId36, "Arc/Circle (Non-Associative) Dialog")
    
    associativeArcBuilder1.Diameter.SetFormula("4.12439503947297")
    
    associativeArcBuilder1.Radius.SetFormula("2.06219751973649")
    
    # ----------------------------------------------
    #   Dialog Begin Arc/Circle (Non-Associative)
    # ----------------------------------------------
    nErrs3 = theSession.UpdateManager.AddToDeleteList(point8)
    
    nErrs4 = theSession.UpdateManager.AddToDeleteList(cartesianCoordinateSystem4)
    
    nErrs5 = theSession.UpdateManager.AddToDeleteList(point7)
    
    associativeArcBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression26)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression25)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    theSession.UndoToMark(markId36, None)
    
    theSession.DeleteUndoMark(markId36, None)
    
    theSession.DeleteUndoMark(markId36, None)
    
    theSession.UndoToMark(markId34, None)
    
    theSession.DeleteUndoMark(markId34, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines1 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    theSession.SetUndoMarkName(markId37, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits49 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits53 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits55 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits57 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits59 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits63 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits67 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    point1_5 = NXOpen.Point3d(44.570603525738761, -2.0696961309506188, 2.8000000000000003)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc1, workPart.ModelingViews.WorkView, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(44.570603525738761, -2.0696961309506188, 2.8000000000000003)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    point1_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    dimensionlinearunits69 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits73 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point9 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point9
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point10 = NXOpen.Point3d(48.302516769311694, 9.3863147466575239, 2.8000000000000003)
    sketchRapidDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point10)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject7 = sketchRapidDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId38, None)
    
    theSession.SetUndoMarkName(markId37, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId37, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder1.Destroy()
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines5 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines8)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId39, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits75 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits79 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits83 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits85 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits93 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    expression27 = workPart.Expressions.FindObject("p4")
    expression27.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId39, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.72737940262519341)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId40, None)
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId39, "Edit Driving Value")
    
    scaleAboutPoint64 = NXOpen.Point3d(-23.255343123888547, -7.7917386755296585, 0.0)
    viewCenter64 = NXOpen.Point3d(23.255343123888593, 7.7917386755297056, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(-18.508376176950467, -5.0826110744993382, 0.0)
    viewCenter65 = NXOpen.Point3d(18.508376176950527, 5.0826110744993835, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(-14.423107652918906, -3.9893702018711781, 0.0)
    viewCenter66 = NXOpen.Point3d(14.423107652918967, 3.9893702018712145, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(-10.617862229595607, 0.36824955709581675, 0.0)
    viewCenter67 = NXOpen.Point3d(10.617862229595683, -0.36824955709578772, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(-8.4942897836764821, 0.29459964567665731, 0.0)
    viewCenter68 = NXOpen.Point3d(8.4942897836765514, -0.29459964567662633, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint68, viewCenter68)
    
    perpendicularDimension1 = theSession.ActiveSketch.FindObject("ENTITY 26 2 1")
    point11 = NXOpen.Point3d(29.620909863210695, -0.77691271724025679, 5.5999999999999499)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(perpendicularDimension1, workPart.ModelingViews.WorkView, point11)
    
    line5 = theSession.ActiveSketch.FindObject("Curve DATUM2")
    point1_8 = NXOpen.Point3d(-14.2875, 0.0, 2.799999999999994)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, NXOpen.View.Null, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    point1_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    sketchRapidDimensionBuilder2.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder1 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList1 = convertToFromReferenceBuilder1.InputObjects
    
    added1 = selectNXObjectList1.Add(perpendicularDimension1)
    
    convertToFromReferenceBuilder1.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject8 = convertToFromReferenceBuilder1.Commit()
    
    convertToFromReferenceBuilder1.Destroy()
    
    expression28 = workPart.Expressions.FindObject("p5")
    expression28.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId41, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId42, None)
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId41, "Edit Driving Value")
    
    scaleAboutPoint69 = NXOpen.Point3d(-8.0131103624046265, 6.3633523466154873, 0.0)
    viewCenter69 = NXOpen.Point3d(8.0131103624047029, -6.3633523466154598, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(-6.4104882899236957, 5.0906818772923925, 0.0)
    viewCenter70 = NXOpen.Point3d(6.4104882899237676, -5.0906818772923632, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(-5.1283906319389505, 4.0725455018339138, 0.0)
    viewCenter71 = NXOpen.Point3d(5.1283906319390216, -4.0725455018338899, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(-4.0222671623050514, 3.2379250656556082, 0.0)
    viewCenter72 = NXOpen.Point3d(4.0222671623051252, -3.2379250656555829, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(-2.944299562807287, 2.6386072584721543, 0.0)
    viewCenter73 = NXOpen.Point3d(2.9442995628073594, -2.6386072584721223, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(-3.6803744535091214, 3.298259073090188, 0.0)
    viewCenter74 = NXOpen.Point3d(3.680374453509188, -3.298259073090156, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(-4.6004680668864069, 4.1228238413627327, 0.0)
    viewCenter75 = NXOpen.Point3d(4.6004680668864788, -4.1228238413626963, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(-5.7505850836080166, 5.1535298017034101, 0.0)
    viewCenter76 = NXOpen.Point3d(5.7505850836080885, -5.1535298017033755, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(-6.2847924411016614, 6.95255163796877, 0.0)
    viewCenter77 = NXOpen.Point3d(6.2847924411017297, -6.9525516379687327, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(-7.8559905513770767, 8.6906895474609662, 0.0)
    viewCenter78 = NXOpen.Point3d(7.8559905513771584, -8.6906895474609236, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(-9.8199881892213554, 10.863361934326198, 0.0)
    viewCenter79 = NXOpen.Point3d(9.8199881892214371, -10.863361934326155, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(-12.27498523652671, 13.579202417907739, 0.0)
    viewCenter80 = NXOpen.Point3d(12.274985236526796, -13.579202417907696, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(-15.343731545658395, 16.782206378063936, 0.0)
    viewCenter81 = NXOpen.Point3d(15.343731545658471, -16.782206378063904, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(-19.17966443207299, 20.977757972579909, 0.0)
    viewCenter82 = NXOpen.Point3d(19.179664432073075, -20.97775797257988, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(-23.674898283340109, 32.665365985874423, 0.0)
    viewCenter83 = NXOpen.Point3d(23.674898283340205, -32.665365985874388, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint83, viewCenter83)
    
    scaleAboutPoint84 = NXOpen.Point3d(-29.59362285417518, 40.83170748234302, 0.0)
    viewCenter84 = NXOpen.Point3d(29.593622854175209, -40.831707482342992, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(-33.948380647590177, 53.615028746883887, 0.0)
    viewCenter85 = NXOpen.Point3d(33.948380647590248, -53.615028746883837, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint85, viewCenter85)
    
    scaleAboutPoint86 = NXOpen.Point3d(-27.158704518072138, 42.892022997507119, 0.0)
    viewCenter86 = NXOpen.Point3d(27.158704518072199, -42.892022997507063, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint86, viewCenter86)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    theSession.UndoToMark(markId43, None)
    
    theSession.DeleteUndoMark(markId43, None)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects2 = [NXOpen.TaggedObject.Null] * 1 
    perpendicularDimension2 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    objects2[0] = perpendicularDimension2
    nErrs6 = theSession.UpdateManager.AddObjectsToDeleteList(objects2)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs7 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId44, None)
    
    scaleAboutPoint87 = NXOpen.Point3d(-26.222197465724832, 40.756786918155235, 0.0)
    viewCenter87 = NXOpen.Point3d(26.222197465724904, -40.7567869181552, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(-32.777746832156041, 50.945983647694042, 0.0)
    viewCenter88 = NXOpen.Point3d(32.777746832156105, -50.945983647693986, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(-40.972183540195054, 63.682479559617533, 0.0)
    viewCenter89 = NXOpen.Point3d(40.972183540195125, -63.682479559617484, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(-32.777746832156041, 50.945983647694042, 0.0)
    viewCenter90 = NXOpen.Point3d(32.777746832156105, -50.945983647693986, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(-26.222197465724808, 40.756786918155235, 0.0)
    viewCenter91 = NXOpen.Point3d(26.222197465724904, -40.756786918155186, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(-20.857885069879391, 32.725302437224641, 0.0)
    viewCenter92 = NXOpen.Point3d(20.857885069879469, -32.725302437224599, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint92, viewCenter92)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete3 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects3 = [NXOpen.TaggedObject.Null] * 1 
    perpendicularDimension3 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    objects3[0] = perpendicularDimension3
    nErrs8 = theSession.UpdateManager.AddObjectsToDeleteList(objects3)
    
    notifyOnDelete4 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id2 = theSession.NewestVisibleUndoMark
    
    nErrs9 = theSession.UpdateManager.DoUpdate(id2)
    
    theSession.DeleteUndoMark(markId46, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines9 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines9)
    
    lines10 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines10)
    
    lines11 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines11)
    
    lines12 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines12)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines13 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines13)
    
    lines14 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines14)
    
    lines15 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines15)
    
    lines16 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines16)
    
    theSession.SetUndoMarkName(markId48, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits95 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    point1_10 = NXOpen.Point3d(31.0810459715238, -3.0, 2.799999999999998)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    point1_11 = NXOpen.Point3d(31.0810459715238, -3.0, 2.799999999999998)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    edge3 = extrude1.FindObject("EDGE * 160 * 170 {(50,-6,2.8)(50,-3,2.8)(50,0,2.8) EXTRUDE(2)}")
    point12 = NXOpen.Point3d(50.0, -1.8095776146642861, 2.7999999999999998)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(edge3, workPart.ModelingViews.WorkView, point12)
    
    point1_13 = NXOpen.Point3d(50.0, -1.8095776146642861, 2.7999999999999998)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge3, workPart.ModelingViews.WorkView, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    point1_14 = NXOpen.Point3d(31.0810459715238, -3.0, 2.799999999999998)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    point1_15 = NXOpen.Point3d(50.0, -1.8095776146642861, 2.7999999999999998)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge3, workPart.ModelingViews.WorkView, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(31.0810459715238, -3.0, 2.799999999999998)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point13 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point13
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder3.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point14 = NXOpen.Point3d(44.858187555511641, 9.4105260780984423, 2.7999999999999998)
    sketchRapidDimensionBuilder3.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point14)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.TextCentered = False
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject9 = sketchRapidDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId49, None)
    
    theSession.SetUndoMarkName(markId48, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId48, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder3.Destroy()
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines17 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines17)
    
    lines18 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines18)
    
    lines19 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines19)
    
    lines20 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines20)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId50, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Destroy()
    
    theSession.UndoToMark(markId50, None)
    
    theSession.DeleteUndoMark(markId50, None)
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    perpendicularDimension4 = nXObject9
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(perpendicularDimension4)
    
    sketchLinearDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId51, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits153 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits155 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits157 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits159 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits161 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits163 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits167 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits168 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits169 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits170 = sketchLinearDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId52, None)
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("395402848")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("395402848")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    nXObject10 = sketchLinearDimensionBuilder3.Commit()
    
    taggedObject1 = sketchLinearDimensionBuilder3.FirstAssociativity.Value
    
    line6 = taggedObject1
    point1_17 = NXOpen.Point3d(50.0, -1.8095776146642857, 2.7999999999999998)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, NXOpen.View.Null, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    point1_18 = NXOpen.Point3d(-395402798.0, -3.0, 2.7999999485564051)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    theSession.SetUndoMarkName(markId53, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId53, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId51, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("3")
    
    sketchLinearDimensionBuilder3.Driving.ExpressionValue.SetFormula("3")
    
    sketchLinearDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    nXObject11 = sketchLinearDimensionBuilder3.Commit()
    
    point1_19 = NXOpen.Point3d(50.0, -1.8095776146642857, 2.7999999999999998)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, NXOpen.View.Null, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    point1_20 = NXOpen.Point3d(47.0, -3.0, 2.7999999999999998)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    theSession.SetUndoMarkName(markId54, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId51, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject12 = sketchLinearDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.SetUndoMarkName(markId51, "Linear Dimension")
    
    expression29 = sketchLinearDimensionBuilder3.Driving.ExpressionValue
    sketchLinearDimensionBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId55, None)
    
    theSession.SetUndoMarkVisibility(markId51, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId54, None)
    
    theSession.DeleteUndoMark(markId53, None)
    
    scaleAboutPoint93 = NXOpen.Point3d(-16.206816445101666, -8.5349506722724762, 0.0)
    viewCenter93 = NXOpen.Point3d(16.206816445101758, 8.5349506722725366, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(-20.2585205563771, -10.668688340340605, 0.0)
    viewCenter94 = NXOpen.Point3d(20.258520556377178, 10.668688340340651, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(-25.323150695471377, -13.335860425425766, 0.0)
    viewCenter95 = NXOpen.Point3d(25.323150695471469, 13.335860425425814, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(-20.2585205563771, -10.668688340340605, 0.0)
    viewCenter96 = NXOpen.Point3d(20.258520556377178, 10.66868834034066, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(-16.206816445101666, -8.5349506722724762, 0.0)
    viewCenter97 = NXOpen.Point3d(16.206816445101758, 8.5349506722725437, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(-12.96545315608132, -6.827960537817968, 0.0)
    viewCenter98 = NXOpen.Point3d(12.965453156081416, 6.8279605378180346, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(-10.372362524865046, -5.4623684302543749, 0.0)
    viewCenter99 = NXOpen.Point3d(10.372362524865144, 5.4623684302544326, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint99, viewCenter99)
    
    scaleAboutPoint100 = NXOpen.Point3d(-8.0032903742153856, -3.6824955709579994, 0.0)
    viewCenter100 = NXOpen.Point3d(8.0032903742154815, 3.6824955709580576, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(-6.4026322993723008, -2.9459964567663834, 0.0)
    viewCenter101 = NXOpen.Point3d(6.4026322993723941, 2.9459964567664549, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(-5.1221058394978307, -2.3567971654130995, 0.0)
    viewCenter102 = NXOpen.Point3d(5.1221058394979249, 2.3567971654131714, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(-4.0976846715982527, -1.8854377323304738, 0.0)
    viewCenter103 = NXOpen.Point3d(4.0976846715983504, 1.8854377323305451, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(-3.2781477372785899, -1.5083501858643726, 0.0)
    viewCenter104 = NXOpen.Point3d(3.2781477372786929, 1.5083501858644441, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(-2.6225181898228604, -1.2066801486914907, 0.0)
    viewCenter105 = NXOpen.Point3d(2.622518189822967, 1.2066801486915615, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(-1.8148469436320005, -0.064356274596845744, 0.0)
    viewCenter106 = NXOpen.Point3d(1.8148469436321062, 0.064356274596916757, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(0.88554233845314045, -0.48395918496851215, 0.0)
    viewCenter107 = NXOpen.Point3d(-0.88554233845303498, 0.48395918496858359, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint107, viewCenter107)
    
    scaleAboutPoint108 = NXOpen.Point3d(0.9524728640338993, -0.68217651072690677, 0.0)
    viewCenter108 = NXOpen.Point3d(-0.95247286403378972, 0.68217651072697782, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint108, viewCenter108)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = -0.0074728370035234901
    rotMatrix1.Xy = 0.98371750922597712
    rotMatrix1.Xz = 0.17956619600960128
    rotMatrix1.Yx = -0.99701011625182834
    rotMatrix1.Yy = 0.006481425955072913
    rotMatrix1.Yz = -0.076998826024200884
    rotMatrix1.Zx = -0.07690893835332159
    rotMatrix1.Zy = -0.17960471363477262
    rotMatrix1.Zz = 0.98072787359263758
    translation1 = NXOpen.Point3d(0.7487264611555311, 45.568933377852289, 1.1346788446983898)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 16.444912946912861)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.03983862296068074
    rotMatrix2.Xy = 0.98527533980547366
    rotMatrix2.Xz = 0.16626902565362228
    rotMatrix2.Yx = -0.99877224105524309
    rotMatrix2.Yy = 0.03436288739067813
    rotMatrix2.Yz = 0.035681962777635794
    rotMatrix2.Zx = 0.029443074195568346
    rotMatrix2.Zy = -0.16748640763173511
    rotMatrix2.Zz = 0.9854346293085765
    translation2 = NXOpen.Point3d(-1.3942591869187, 45.427000654255707, -3.7509514555842074)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 16.444912946912861)
    
    scaleAboutPoint109 = NXOpen.Point3d(-0.9653441189531643, -0.93316598165474396, 0.0)
    viewCenter109 = NXOpen.Point3d(0.96534411895327588, 0.93316598165481501, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(-1.2066801486914696, -1.2267914845030157, 0.0)
    viewCenter110 = NXOpen.Point3d(1.206680148691579, 1.2267914845030869, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(-2.0865510904457039, -1.3072368277491169, 0.0)
    viewCenter111 = NXOpen.Point3d(2.0865510904458167, 1.3072368277491881, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(-1.6692408723565522, -1.0457894621992871, 0.0)
    viewCenter112 = NXOpen.Point3d(1.6692408723566663, 1.0457894621993584, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(-1.3353926978852302, -0.8366315697594221, 0.0)
    viewCenter113 = NXOpen.Point3d(1.3353926978853432, 0.83663156975949304, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(-1.0683141583081719, -0.66930525580753053, 0.0)
    viewCenter114 = NXOpen.Point3d(1.0683141583082876, 0.66930525580760158, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint114, viewCenter114)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.039843988395146017
    rotMatrix3.Xy = 0.9984265472800018
    rotMatrix3.Xz = -0.039457398232798903
    rotMatrix3.Yx = -0.99899331752477527
    rotMatrix3.Yy = 0.038989895315553094
    rotMatrix3.Yz = -0.022184219709690259
    rotMatrix3.Zx = -0.020610874062325962
    rotMatrix3.Zy = 0.040301584954148158
    rotMatrix3.Zz = 0.99897496170853639
    translation3 = NXOpen.Point3d(-0.39959105263323103, 45.756257636603777, -1.1971072320186504)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 25.695176479551346)
    
    scaleAboutPoint115 = NXOpen.Point3d(2.5948449917463141, -0.27801910625849213, 0.0)
    viewCenter115 = NXOpen.Point3d(-2.5948449917461973, 0.27801910625856358, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(2.0758759933970619, -0.22241528500678653, 0.0)
    viewCenter116 = NXOpen.Point3d(-2.0758759933969468, 0.22241528500685795, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(1.6607007947176626, -0.17793222800542255, 0.0)
    viewCenter117 = NXOpen.Point3d(-1.6607007947175458, 0.17793222800549371, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(1.3285606357741415, -0.14234578240433099, 0.0)
    viewCenter118 = NXOpen.Point3d(-1.3285606357740252, 0.14234578240440163, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(0.73808924209677196, 0.071700097803716181, 0.0)
    viewCenter119 = NXOpen.Point3d(-0.73808924209665494, -0.071700097803645044, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(0.92261155262094985, 0.084353056239659552, 0.0)
    viewCenter120 = NXOpen.Point3d(-0.9226115526208335, -0.084353056239588914, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(1.1532644407761747, 0.10544132029956564, 0.0)
    viewCenter121 = NXOpen.Point3d(-1.1532644407760568, -0.10544132029949448, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(1.4415805509702031, 0.13180165037444794, 0.0)
    viewCenter122 = NXOpen.Point3d(-1.4415805509700836, -0.13180165037437716, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(1.7504906690352324, 0.061782023613041741, 0.0)
    viewCenter123 = NXOpen.Point3d(-1.7504906690351141, -0.061782023612971131, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(2.1881133362940255, 0.077227529516293039, 0.0)
    viewCenter124 = NXOpen.Point3d(-2.1881133362939096, -0.077227529516222027, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(2.7351416703675193, 0.096534411895357441, 0.0)
    viewCenter125 = NXOpen.Point3d(-2.7351416703674012, -0.096534411895286415, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(3.4189270879593852, 0.12066801486918888, 0.0)
    viewCenter126 = NXOpen.Point3d(-3.4189270879592675, -0.12066801486911753, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(4.2736588599492142, 0.15083501858647613, 0.0)
    viewCenter127 = NXOpen.Point3d(-4.2736588599490952, -0.1508350185864048, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(2.1996773543856567, -0.56563131969911451, 0.0)
    viewCenter128 = NXOpen.Point3d(-2.1996773543855355, 0.56563131969918634, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(1.7597418835085372, -0.45250505575928562, 0.0)
    viewCenter129 = NXOpen.Point3d(-1.7597418835084162, 0.45250505575935696, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(1.4077935068068408, -0.36200404460742053, 0.0)
    viewCenter130 = NXOpen.Point3d(-1.4077935068067202, 0.36200404460749191, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(1.1262348054454865, -0.2896032356859301, 0.0)
    viewCenter131 = NXOpen.Point3d(-1.1262348054453635, 0.2896032356860011, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.43573098631491947
    rotMatrix4.Xy = 0.83774347758513912
    rotMatrix4.Xz = 0.32912668279643548
    rotMatrix4.Yx = -0.81125683746383837
    rotMatrix4.Yy = 0.20714502669961732
    rotMatrix4.Yz = 0.54676620376701024
    rotMatrix4.Zx = 0.38987286547437622
    rotMatrix4.Zy = -0.50524924906146307
    rotMatrix4.Zz = 0.76988463102573257
    translation4 = NXOpen.Point3d(-17.724288419896499, 37.227890620030571, -20.788193513310407)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 20.556141183641088)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.83401032901221417
    rotMatrix5.Xy = 0.55174856294374386
    rotMatrix5.Xz = -0.00054257760261200872
    rotMatrix5.Yx = -0.147600130246025
    rotMatrix5.Yy = 0.22405625517267577
    rotMatrix5.Yz = 0.96333431168486616
    rotMatrix5.Zx = 0.53163989001230727
    rotMatrix5.Zy = -0.80335068171223534
    rotMatrix5.Zz = 0.26830339084736121
    translation5 = NXOpen.Point3d(-36.525626663392352, 6.1810715682457076, -27.592698608354826)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 20.556141183641088)
    
    scaleAboutPoint132 = NXOpen.Point3d(2.7930623175047122, 0.11584129427442176, 0.0)
    viewCenter132 = NXOpen.Point3d(-2.7930623175045883, -0.11584129427435075, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(2.3477168972942963, 0.31920712200056645, 0.0)
    viewCenter133 = NXOpen.Point3d(-2.3477168972941689, -0.31920712200049661, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(1.9111239304290539, 0.31302891963926666, 0.0)
    viewCenter134 = NXOpen.Point3d(-1.911123930428926, -0.31302891963919588, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(1.5618495569368587, 0.28996363082374393, 0.0)
    viewCenter135 = NXOpen.Point3d(-1.561849556936731, -0.28996363082367332, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint135, viewCenter135)
    
    scaleAboutPoint136 = NXOpen.Point3d(1.9523119461710579, 0.36245453852967086, 0.0)
    viewCenter136 = NXOpen.Point3d(-1.95231194617093, -0.36245453852960202, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(2.4403899327138054, 0.45306817316207948, 0.0)
    viewCenter137 = NXOpen.Point3d(-2.440389932713678, -0.45306817316200965, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(3.0504874158922402, 0.56633521645259011, 0.0)
    viewCenter138 = NXOpen.Point3d(-3.0504874158921131, -0.56633521645252116, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint138, viewCenter138)
    
    scaleAboutPoint139 = NXOpen.Point3d(3.3143481417394542, 0.41831578487976301, 0.0)
    viewCenter139 = NXOpen.Point3d(-3.3143481417393263, -0.41831578487969456, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(3.6401517818861655, 0.34189270879596489, 0.0)
    viewCenter140 = NXOpen.Point3d(-3.6401517818860385, -0.34189270879589834, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(4.2987980297136232, 0.40222671623054146, 0.0)
    viewCenter141 = NXOpen.Point3d(-4.2987980297134962, -0.40222671623047407, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint141, viewCenter141)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId57, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves1 = [NXOpen.ICurve.Null] * 1 
    curves1[0] = arc1
    seedPoint1 = NXOpen.Point3d(46.499999999999993, -3.0000000000000027, 2.8000000000000003)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves1, seedPoint1, 0.01)
    
    section3.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = regionBoundaryRule1
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section3.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId58, None)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId60, None)
    
    direction4 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction4
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies6[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies6)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies7)
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId59, None)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies8)
    
    direction5 = extrudeBuilder3.Direction
    
    success1 = direction5.ReverseDirection()
    
    extrudeBuilder3.Direction = direction5
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies15)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("7.8")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies18)
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    section3.Clear()
    
    theSession.DeleteUndoMark(markId62, None)
    
    workPart.Expressions.Delete(expression31)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies19)
    
    targetBodies20 = []
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies20)
    
    theSession.DeleteUndoMark(markId61, None)
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features2 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature2 = feature3
    features2[0] = sketchFeature2
    curveFeatureRule2 = workPart.ScRuleFactory.CreateRuleCurveFeature(features2)
    
    section3.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = curveFeatureRule2
    helpPoint3 = NXOpen.Point3d(47.307639027319311, -4.4669046702886028, 2.7999999999999998)
    section3.AddToSection(rules3, arc1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId64, None)
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies22)
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId63, None)
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId65, None)
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature4 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId66, None)
    
    theSession.SetUndoMarkName(markId57, "Extrude")
    
    expression33 = extrudeBuilder3.Limits.StartExtend.Value
    expression34 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression30)
    
    workPart.Expressions.Delete(expression32)
    
    scaleAboutPoint142 = NXOpen.Point3d(0.31423962205515105, 4.933562066264864, 0.0)
    viewCenter142 = NXOpen.Point3d(-0.31423962205501976, -4.9335620662647948, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(0.25139169764412866, 3.9468496530118955, 0.0)
    viewCenter143 = NXOpen.Point3d(-0.25139169764400582, -3.946849653011828, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(0.20111335811531883, 3.1574797224095232, 0.0)
    viewCenter144 = NXOpen.Point3d(-0.2011133581151904, -3.1574797224094548, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint144, viewCenter144)
    
    scaleAboutPoint145 = NXOpen.Point3d(0.77227529516264182, 1.6732631395189483, 0.0)
    viewCenter145 = NXOpen.Point3d(-0.7722752951625137, -1.6732631395188799, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(0.96534411895328653, 2.0915789243986778, 0.0)
    viewCenter146 = NXOpen.Point3d(-0.96534411895315808, -2.091578924398608, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint146, viewCenter146)
    
    scaleAboutPoint147 = NXOpen.Point3d(1.2066801486915901, 2.6144736554983372, 0.0)
    viewCenter147 = NXOpen.Point3d(-1.2066801486914633, -2.6144736554982675, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(1.5083501858644706, 3.2680920693729143, 0.0)
    viewCenter148 = NXOpen.Point3d(-1.5083501858643467, -3.2680920693728472, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(2.1996773543856567, 4.2422348977436748, 0.0)
    viewCenter149 = NXOpen.Point3d(-2.1996773543855328, -4.2422348977436073, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(2.7495966929820463, 5.3027936221795802, 0.0)
    viewCenter150 = NXOpen.Point3d(-2.7495966929819304, -5.3027936221795189, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint150, viewCenter150)
    
    scaleAboutPoint151 = NXOpen.Point3d(3.4369958662275546, 6.6284920277244677, 0.0)
    viewCenter151 = NXOpen.Point3d(-3.4369958662274285, -6.6284920277244099, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint151, viewCenter151)
    
    scaleAboutPoint152 = NXOpen.Point3d(4.2962448327844109, 8.2856150346555761, 0.0)
    viewCenter152 = NXOpen.Point3d(-4.2962448327843026, -8.2856150346555157, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint152, viewCenter152)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.86656950044761871
    rotMatrix6.Xy = 0.49344475614851074
    rotMatrix6.Xz = -0.074629575394108347
    rotMatrix6.Yx = -0.46018267074219082
    rotMatrix6.Yy = 0.84794668204389645
    rotMatrix6.Yz = 0.26309377407938778
    rotMatrix6.Zx = 0.193104144032574
    rotMatrix6.Zy = -0.19364580305363746
    rotMatrix6.Zz = 0.96187945841314304
    translation6 = NXOpen.Point3d(-29.626149812337555, 23.525649393382622, -18.271196817477794)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 2.7589985661155403)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin10, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane8
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression36 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId68, "Create Sketch Dialog")
    
    scalar9 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point15 = workPart.Points.CreatePoint(edge2, scalar9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction6 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction6, point15, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem5
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin11, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane9.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom6 = [NXOpen.NXObject.Null] * 1 
    geom6[0] = face1
    plane9.SetGeometry(geom6)
    
    plane9.SetFlip(False)
    
    plane9.SetExpression(None)
    
    plane9.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane9.Evaluate()
    
    origin12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin12, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression37 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane10.SynchronizeToPlane(plane9)
    
    scalar10 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point16 = workPart.Points.CreatePoint(edge2, scalar10, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane10.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom7 = [NXOpen.NXObject.Null] * 1 
    geom7[0] = face1
    plane10.SetGeometry(geom7)
    
    plane10.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane10.Evaluate()
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId69, None)
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject13 = sketchInPlaceBuilder3.Commit()
    
    sketch4 = nXObject13
    feature5 = sketch4.Feature
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs10 = theSession.UpdateManager.DoUpdate(markId71)
    
    sketch4.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId70, None)
    
    theSession.SetUndoMarkName(markId68, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression36)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point16)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression35)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane8.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression38)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression37)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    scaleAboutPoint153 = NXOpen.Point3d(12.466781880847519, 1.7261697988866005, 0.0)
    viewCenter153 = NXOpen.Point3d(-12.466781880847414, -1.7261697988865399, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(15.343731545658478, 2.1577122486082412, 0.0)
    viewCenter154 = NXOpen.Point3d(-15.343731545658365, -2.1577122486081848, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint154, viewCenter154)
    
    scaleAboutPoint155 = NXOpen.Point3d(19.179664432073086, 2.6971403107603011, 0.0)
    viewCenter155 = NXOpen.Point3d(-19.179664432072979, -2.6971403107602421, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint155, viewCenter155)
    
    scaleAboutPoint156 = NXOpen.Point3d(23.974580540091338, 3.3714253884503615, 0.0)
    viewCenter156 = NXOpen.Point3d(-23.974580540091221, -3.3714253884503029, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint156, viewCenter156)
    
    scaleAboutPoint157 = NXOpen.Point3d(42.611070881802938, 2.1071408677814945, 0.0)
    viewCenter157 = NXOpen.Point3d(-42.611070881802846, -2.1071408677814389, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint157, viewCenter157)
    
    scaleAboutPoint158 = NXOpen.Point3d(34.088856705442389, 1.6857126942251952, 0.0)
    viewCenter158 = NXOpen.Point3d(-34.088856705442211, -1.6857126942251361, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint158, viewCenter158)
    
    scaleAboutPoint159 = NXOpen.Point3d(28.020291006231776, 1.3485701553801563, 0.0)
    viewCenter159 = NXOpen.Point3d(-28.020291006231613, -1.348570155380109, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint159, viewCenter159)
    
    scaleAboutPoint160 = NXOpen.Point3d(23.015597318487725, 2.1577122486082407, 0.0)
    viewCenter160 = NXOpen.Point3d(-23.015597318487554, -2.1577122486081843, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint160, viewCenter160)
    
    scaleAboutPoint161 = NXOpen.Point3d(18.412477854790197, 1.7261697988866005, 0.0)
    viewCenter161 = NXOpen.Point3d(-18.41247785479003, -1.7261697988865399, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint161, viewCenter161)
    
    scaleAboutPoint162 = NXOpen.Point3d(14.729982283832168, 1.3809358391092865, 0.0)
    viewCenter162 = NXOpen.Point3d(-14.729982283832012, -1.3809358391092259, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(11.783985827065743, 1.1047486712874339, 0.0)
    viewCenter163 = NXOpen.Point3d(-11.783985827065603, -1.1047486712873757, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint163, viewCenter163)
    
    scaleAboutPoint164 = NXOpen.Point3d(9.427188661652611, 0.88379893702995493, 0.0)
    viewCenter164 = NXOpen.Point3d(-9.427188661652476, -0.88379893702989687, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint164, viewCenter164)
    
    scaleAboutPoint165 = NXOpen.Point3d(-9.8199881892213234, 3.1816761733077588, 0.0)
    viewCenter165 = NXOpen.Point3d(9.8199881892214513, -3.1816761733077028, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint165, viewCenter165)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId73, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(4.2000000000000002, -2.6999999999999997, 2.799999999999994)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 2.3331730408363338, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = arc2
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(4.2000000000000002, -2.3436968064887229, 2.799999999999994)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension4 = sketchDimensionalConstraint4.AssociatedDimension
    
    expression39 = sketchDimensionalConstraint4.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines21 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines21)
    
    lines22 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines22)
    
    lines23 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines23)
    
    lines24 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines24)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines25 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines25)
    
    lines26 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines26)
    
    lines27 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines27)
    
    lines28 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines28)
    
    theSession.SetUndoMarkName(markId74, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits171 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits172 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits173 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits174 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits175 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits176 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits177 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits178 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits179 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits180 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits181 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits182 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits183 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits184 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits185 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits186 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits187 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits188 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits189 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits190 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint166 = NXOpen.Point3d(-11.842991472642407, -1.0298253454471447, 0.0)
    viewCenter166 = NXOpen.Point3d(11.842991472642542, 1.0298253454472006, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint166, viewCenter166)
    
    scaleAboutPoint167 = NXOpen.Point3d(-9.4743931781139121, -0.82386027635770909, 0.0)
    viewCenter167 = NXOpen.Point3d(9.4743931781140489, 0.82386027635776515, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint167, viewCenter167)
    
    point1_21 = NXOpen.Point3d(5.0918347052791555, -4.85599798166536, 2.799999999999994)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc2, workPart.ModelingViews.WorkView, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    point1_22 = NXOpen.Point3d(5.0918347052791555, -4.85599798166536, 2.799999999999994)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    point1_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    dimensionlinearunits191 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits192 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits193 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits194 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits195 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits196 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits197 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits198 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits199 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits200 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits201 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits202 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Destroy()
    
    theSession.UndoToMark(markId74, None)
    
    theSession.DeleteUndoMark(markId74, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete5 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects4 = [NXOpen.TaggedObject.Null] * 1 
    objects4[0] = arc2
    nErrs11 = theSession.UpdateManager.AddObjectsToDeleteList(objects4)
    
    notifyOnDelete6 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id3 = theSession.NewestVisibleUndoMark
    
    nErrs12 = theSession.UpdateManager.DoUpdate(id3)
    
    theSession.DeleteUndoMark(markId75, None)
    
    scaleAboutPoint168 = NXOpen.Point3d(-6.6850376710169996, 1.0121711966681037, 0.0)
    viewCenter168 = NXOpen.Point3d(6.6850376710171382, -1.0121711966680471, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint168, viewCenter168)
    
    scaleAboutPoint169 = NXOpen.Point3d(-5.310367952751518, 3.3707654735551165, 0.0)
    viewCenter169 = NXOpen.Point3d(5.3103679527516574, -3.370765473555057, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint169, viewCenter169)
    
    scaleAboutPoint170 = NXOpen.Point3d(-6.637959940939413, 4.2134568419438869, 0.0)
    viewCenter170 = NXOpen.Point3d(6.6379599409395569, -4.2134568419438265, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint170, viewCenter170)
    
    scaleAboutPoint171 = NXOpen.Point3d(-8.297449926174286, 5.2668210524298518, 0.0)
    viewCenter171 = NXOpen.Point3d(8.2974499261744299, -5.2668210524297896, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint171, viewCenter171)
    
    scaleAboutPoint172 = NXOpen.Point3d(-10.371812407717874, 6.5835263155373065, 0.0)
    viewCenter172 = NXOpen.Point3d(10.371812407718018, -6.5835263155372461, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint172, viewCenter172)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.DeleteUndoMark(markId78, "Create Rectangle")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId80, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(0.0, -12.790430145949378, 2.799999999999994)
    endPoint5 = NXOpen.Point3d(21.5, -12.790430145949378, 2.799999999999994)
    line7 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(21.5, -12.790430145949378, 2.799999999999994)
    endPoint6 = NXOpen.Point3d(21.5, 5.7095698540506223, 2.799999999999994)
    line8 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(21.5, 5.7095698540506223, 2.799999999999994)
    endPoint7 = NXOpen.Point3d(0.0, 5.7095698540506223, 2.799999999999994)
    line9 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(0.0, 5.7095698540506223, 2.799999999999994)
    endPoint8 = NXOpen.Point3d(0.0, -12.790430145949378, 2.799999999999994)
    line10 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line7
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = line8
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line8
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line9
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line9
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line10
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line10
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line7
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    geom8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom8.Geometry = line7
    geom8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateHorizontalConstraint(geom8)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line7
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line8
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line8
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line9
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line9
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line10
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line10
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line7
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = line7
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line7
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 0.0
    dimObject2_3.HelpPoint.Y = 0.0
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(10.75, -15.91813366980468, 2.799999999999994)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_5, dimObject2_3, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint3 = sketchDimensionalConstraint5
    dimension5 = sketchHelpedDimensionalConstraint3.AssociatedDimension
    
    expression40 = sketchHelpedDimensionalConstraint3.AssociatedExpression
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = line8
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_4.Geometry = line8
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 0.0
    dimObject2_4.HelpPoint.Y = 0.0
    dimObject2_4.HelpPoint.Z = 0.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(24.627703523855303, -3.5404301459493777, 2.799999999999994)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_6, dimObject2_4, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint4 = sketchDimensionalConstraint6
    dimension6 = sketchHelpedDimensionalConstraint4.AssociatedDimension
    
    expression41 = sketchHelpedDimensionalConstraint4.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line7
    geoms3[1] = line8
    geoms3[2] = line9
    geoms3[3] = line10
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line7
    geoms4[1] = line8
    geoms4[2] = line9
    geoms4[3] = line10
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder6 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines29 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines29)
    
    lines30 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines30)
    
    lines31 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines31)
    
    lines32 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines32)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines33 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines33)
    
    lines34 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines34)
    
    lines35 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines35)
    
    lines36 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines36)
    
    theSession.SetUndoMarkName(markId81, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder6.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits203 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits204 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits205 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits206 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits207 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits208 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits209 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits210 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits211 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits212 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits213 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits214 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits215 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits216 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits217 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits218 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits219 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits220 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits221 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits222 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    point17 = NXOpen.Point3d(17.571282972639153, 5.7095698540506206, 2.799999999999994)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(line9, workPart.ModelingViews.WorkView, point17)
    
    point1_24 = NXOpen.Point3d(21.5, 5.7095698540506223, 2.799999999999994)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, workPart.ModelingViews.WorkView, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    point1_25 = NXOpen.Point3d(0.0, 5.7095698540506223, 2.799999999999994)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    dimensionlinearunits223 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits224 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits225 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits226 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits227 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits228 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    point1_26 = NXOpen.Point3d(25.0, 0.0, 2.7999999999999967)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    point1_27 = NXOpen.Point3d(17.571282972639153, 5.7095698540506206, 2.799999999999994)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, workPart.ModelingViews.WorkView, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    point1_28 = NXOpen.Point3d(25.0, 0.0, 2.7999999999999967)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    point1_29 = NXOpen.Point3d(17.571282972639153, 5.7095698540506206, 2.799999999999994)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, workPart.ModelingViews.WorkView, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    point1_30 = NXOpen.Point3d(25.0, 0.0, 2.7999999999999967)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    dimensionlinearunits229 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits230 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits231 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits232 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits233 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits234 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits235 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits236 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits237 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits238 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits239 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits240 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point18 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin4.PointOnGeometry = point18
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder6.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point19 = NXOpen.Point3d(18.214923813543635, 2.9327961104315481, 2.799999999999994)
    sketchRapidDimensionBuilder6.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point19)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.TextCentered = True
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject14 = sketchRapidDimensionBuilder6.Commit()
    
    theSession.DeleteUndoMark(markId82, None)
    
    theSession.SetUndoMarkName(markId81, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId81, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder6.Destroy()
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder7 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines37 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines37)
    
    lines38 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines38)
    
    lines39 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines39)
    
    lines40 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines40)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId83, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder7.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits241 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits242 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits243 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits244 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits245 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits246 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits247 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits248 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits249 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits250 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits251 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits252 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits253 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits254 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits255 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits256 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits257 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits258 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits259 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits260 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    expression42 = workPart.Expressions.FindObject("p9")
    expression42.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId83, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId84, None)
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId83, "Edit Driving Value")
    
    point20 = NXOpen.Point3d(18.85856465444812, -17.0, 2.799999999999994)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(line7, workPart.ModelingViews.WorkView, point20)
    
    point1_31 = NXOpen.Point3d(21.500000000000007, -17.0, 2.799999999999994)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, workPart.ModelingViews.WorkView, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    point1_32 = NXOpen.Point3d(7.1939254187469345e-15, -17.0, 2.799999999999994)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, workPart.ModelingViews.WorkView, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    dimensionlinearunits261 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits262 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits263 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits264 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits265 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits266 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    edge4 = extrude1.FindObject("EDGE * 130 * 160 {(0,-6,2.8)(25,-6,2.8)(50,-6,2.8) EXTRUDE(2)}")
    point1_33 = NXOpen.Point3d(25.0, -6.0, 2.7999999999999967)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge4, workPart.ModelingViews.WorkView, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    point1_34 = NXOpen.Point3d(18.85856465444812, -17.0, 2.799999999999994)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line7, workPart.ModelingViews.WorkView, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    point1_35 = NXOpen.Point3d(25.0, -6.0, 2.7999999999999967)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge4, workPart.ModelingViews.WorkView, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    point1_36 = NXOpen.Point3d(18.85856465444812, -17.0, 2.799999999999994)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line7, workPart.ModelingViews.WorkView, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    point1_37 = NXOpen.Point3d(25.0, -6.0, 2.7999999999999967)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge4, workPart.ModelingViews.WorkView, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    dimensionlinearunits267 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits268 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits269 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits270 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits271 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits272 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits273 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits274 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits275 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits276 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits277 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits278 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits279 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits280 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits281 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits282 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits283 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits284 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Destroy()
    
    theSession.UndoToMark(markId85, None)
    
    theSession.DeleteUndoMark(markId85, None)
    
    sketchRapidDimensionBuilder7.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder8 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines41 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines41)
    
    lines42 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines42)
    
    lines43 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines43)
    
    lines44 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines44)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines45 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines45)
    
    lines46 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines46)
    
    lines47 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines47)
    
    lines48 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines48)
    
    theSession.SetUndoMarkName(markId86, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder8.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits285 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits286 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits287 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits288 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits289 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits290 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits291 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits292 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits293 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits294 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits295 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits296 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits297 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits298 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits299 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits300 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits301 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits302 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits303 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits304 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    point21 = NXOpen.Point3d(17.203488206408021, -6.0, 2.7999999999999958)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(edge4, workPart.ModelingViews.WorkView, point21)
    
    point1_38 = NXOpen.Point3d(21.500000000000007, -17.0, 2.799999999999994)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, workPart.ModelingViews.WorkView, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    dimensionlinearunits305 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits306 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits307 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits308 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits309 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits310 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin5 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin5.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin5.View = NXOpen.View.Null
    assocOrigin5.ViewOfGeometry = workPart.ModelingViews.WorkView
    point22 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin5.PointOnGeometry = point22
    assocOrigin5.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.DimensionLine = 0
    assocOrigin5.AssociatedView = NXOpen.View.Null
    assocOrigin5.AssociatedPoint = NXOpen.Point.Null
    assocOrigin5.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.XOffsetFactor = 0.0
    assocOrigin5.YOffsetFactor = 0.0
    assocOrigin5.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder8.Origin.SetAssociativeOrigin(assocOrigin5)
    
    point23 = NXOpen.Point3d(28.605125959573137, -12.698481454391597, 2.799999999999994)
    sketchRapidDimensionBuilder8.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point23)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.TextCentered = False
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject15 = sketchRapidDimensionBuilder8.Commit()
    
    theSession.DeleteUndoMark(markId87, None)
    
    theSession.SetUndoMarkName(markId86, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId86, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder8.Destroy()
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder9 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines49 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines49)
    
    lines50 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines50)
    
    lines51 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines51)
    
    lines52 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines52)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId88, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder9.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits311 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits312 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits313 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits314 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits315 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits316 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits317 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits318 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits319 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits320 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits321 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits322 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits323 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits324 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits325 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits326 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits327 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits328 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits329 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits330 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    expression43 = workPart.Expressions.FindObject("p10")
    expression43.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId88, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId89, None)
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId88, "Edit Driving Value")
    
    expression43.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId90, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId91, None)
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId90, "Edit Driving Value")
    
    parallelDimension3 = dimension5
    point24 = NXOpen.Point3d(11.226823255152112, -10.859507623235935, 5.6000000000001755)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(parallelDimension3, workPart.ModelingViews.WorkView, point24)
    
    point1_39 = NXOpen.Point3d(21.500000000000004, -7.5, 2.799999999999994)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, NXOpen.View.Null, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    sketchRapidDimensionBuilder9.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder2 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList2 = convertToFromReferenceBuilder2.InputObjects
    
    added2 = selectNXObjectList2.Add(parallelDimension3)
    
    convertToFromReferenceBuilder2.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject16 = convertToFromReferenceBuilder2.Commit()
    
    convertToFromReferenceBuilder2.Destroy()
    
    expression44 = workPart.Expressions.FindObject("p11")
    expression44.SetFormula("6.7")
    
    theSession.SetUndoMarkVisibility(markId92, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId93, None)
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId92, "Edit Driving Value")
    
    expression44.SetFormula("6.7")
    
    theSession.SetUndoMarkVisibility(markId94, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId95, None)
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId94, "Edit Driving Value")
    
    expression44.SetFormula("6.7")
    
    theSession.SetUndoMarkVisibility(markId96, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId97, None)
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId96, "Edit Driving Value")
    
    sketchRapidDimensionBuilder9.Destroy()
    
    theSession.UndoToMark(markId98, None)
    
    theSession.DeleteUndoMark(markId98, None)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension4 = nXObject16
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension4)
    
    sketchLinearDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId99, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits331 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits332 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits333 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits334 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits335 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits336 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits337 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits338 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits339 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits340 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits341 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits342 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits343 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits344 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits345 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits346 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits347 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits348 = sketchLinearDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId100, None)
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionValue.SetFormula("8")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionValue.SetFormula("8")
    
    sketchLinearDimensionBuilder4.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    nXObject17 = sketchLinearDimensionBuilder4.Commit()
    
    point1_41 = NXOpen.Point3d(13.5, -7.5, 2.799999999999994)
    point2_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, NXOpen.View.Null, point1_41, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_41)
    
    point1_42 = NXOpen.Point3d(21.500000000000004, -7.5, 2.799999999999994)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line7, NXOpen.View.Null, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    theSession.SetUndoMarkName(markId101, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId101, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId99, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject18 = sketchLinearDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId103, None)
    
    theSession.SetUndoMarkName(markId99, "Linear Dimension")
    
    expression45 = sketchLinearDimensionBuilder4.Driving.ExpressionValue
    sketchLinearDimensionBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId102, None)
    
    theSession.SetUndoMarkVisibility(markId99, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId101, None)
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line10
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = edge2
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreateParallelConstraint(conGeom1_9, conGeom2_9)
    
    theSession.SetUndoMarkVisibility(markId105, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    perpendicularDimension5 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    theSession.UpdateManager.LogForUpdate(perpendicularDimension5)
    
    startPoint9 = NXOpen.Point3d(6.0526198182924205, -7.5, 2.799999999999994)
    endPoint9 = NXOpen.Point3d(6.0526198182924169, 1.4999999999999964, 2.799999999999994)
    line8.SetEndpoints(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(-1.9473801817075795, 1.4999999999999947, 2.799999999999994)
    endPoint10 = NXOpen.Point3d(-1.9473801817075795, -7.5, 2.799999999999994)
    line10.SetEndpoints(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(6.0526198182924169, 1.4999999999999964, 2.799999999999994)
    endPoint11 = NXOpen.Point3d(-1.9473801817075795, 1.4999999999999947, 2.799999999999994)
    line9.SetEndpoints(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(-1.9473801817075795, -7.5, 2.799999999999994)
    endPoint12 = NXOpen.Point3d(6.0526198182924205, -7.5, 2.799999999999994)
    line7.SetEndpoints(startPoint12, endPoint12)
    
    sketchHelpedDimensionalConstraint5 = theSession.ActiveSketch.FindObject("DimensionalConstraint p10")
    sketchHelpedDimensionalConstraint5.Refresh()
    
    sketchHelpedDimensionalConstraint6 = theSession.ActiveSketch.FindObject("ENTITY 243 21 1")
    sketchHelpedDimensionalConstraint6.Refresh()
    
    sketchHelpedDimensionalConstraint7 = theSession.ActiveSketch.FindObject("DimensionalConstraint p9")
    sketchHelpedDimensionalConstraint7.Refresh()
    
    nErrs13 = theSession.UpdateManager.DoUpdate(markId105)
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line8
    geoms5[1] = line10
    geoms5[2] = line9
    geoms5[3] = line7
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line8
    geoms6[1] = line10
    geoms6[2] = line9
    geoms6[3] = line7
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms6)
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line8
    geoms7[1] = line10
    geoms7[2] = line9
    geoms7[3] = line7
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms7)
    
    scaleAboutPoint173 = NXOpen.Point3d(-16.182969714169772, 5.4709471476881335, 0.0)
    viewCenter173 = NXOpen.Point3d(16.182969714169918, -5.4709471476880713, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint173, viewCenter173)
    
    scaleAboutPoint174 = NXOpen.Point3d(-11.695873566149951, 4.6709935311354167, 0.0)
    viewCenter174 = NXOpen.Point3d(11.695873566150093, -4.670993531135351, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint174, viewCenter174)
    
    scaleAboutPoint175 = NXOpen.Point3d(-9.5626639220093832, 2.8963837840701965, 0.0)
    viewCenter175 = NXOpen.Point3d(9.5626639220095235, -2.8963837840701339, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint175, viewCenter175)
    
    scaleAboutPoint176 = NXOpen.Point3d(-7.2087774181301283, 2.3906659805023946, 0.0)
    viewCenter176 = NXOpen.Point3d(7.2087774181302775, -2.3906659805023285, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint176, viewCenter176)
    
    scaleAboutPoint177 = NXOpen.Point3d(-5.5316332841161655, 1.971379946998908, 0.0)
    viewCenter177 = NXOpen.Point3d(5.5316332841163112, -1.9713799469988349, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint177, viewCenter177)
    
    scaleAboutPoint178 = NXOpen.Point3d(-6.9145416051452226, 2.4642249337486235, 0.0)
    viewCenter178 = NXOpen.Point3d(6.9145416051453719, -2.4642249337485516, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint178, viewCenter178)
    
    scaleAboutPoint179 = NXOpen.Point3d(-8.6431770064315483, 3.0802811671857699, 0.0)
    viewCenter179 = NXOpen.Point3d(8.6431770064316957, -3.0802811671857007, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint179, viewCenter179)
    
    scaleAboutPoint180 = NXOpen.Point3d(-23.906659805023565, 6.6088122057156999, 0.0)
    viewCenter180 = NXOpen.Point3d(23.906659805023722, -6.6088122057156307, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint180, viewCenter180)
    
    scaleAboutPoint181 = NXOpen.Point3d(-19.125327844018837, 5.287049764572564, 0.0)
    viewCenter181 = NXOpen.Point3d(19.125327844018997, -5.2870497645725019, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint181, viewCenter181)
    
    scaleAboutPoint182 = NXOpen.Point3d(-14.417554836260335, 4.3031987649042911, 0.0)
    viewCenter182 = NXOpen.Point3d(14.417554836260489, -4.3031987649042218, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint182, viewCenter182)
    
    scaleAboutPoint183 = NXOpen.Point3d(-11.475196706411275, 3.4425590119234393, 0.0)
    viewCenter183 = NXOpen.Point3d(11.475196706411424, -3.4425590119233687, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint183, viewCenter183)
    
    scaleAboutPoint184 = NXOpen.Point3d(-9.180157365129002, 2.7540472095387565, 0.0)
    viewCenter184 = NXOpen.Point3d(9.1801573651291548, -2.7540472095386894, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint184, viewCenter184)
    
    scaleAboutPoint185 = NXOpen.Point3d(-7.3441258921031869, 2.2032377676310122, 0.0)
    viewCenter185 = NXOpen.Point3d(7.3441258921033397, -2.2032377676309443, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint185, viewCenter185)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Sketch Constraints->Point on Curve
    # ----------------------------------------------
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraints")
    
    sketchConstraintBuilder1 = workPart.Sketches.CreateConstraintBuilder()
    
    point1_43 = NXOpen.Point3d(8.8498061145931694e-17, -3.0, 2.7999999999999936)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    added3 = sketchConstraintBuilder1.GeometryToConstrain.Add(NXOpen.InferSnapType.SnapType.Mid, edge2, workPart.ModelingViews.WorkView, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    point1_44 = NXOpen.Point3d(-1.9473801817075795, -1.3283710685878294, 2.799999999999994)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchConstraintBuilder1.GeometryToConstrainTo.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line10, workPart.ModelingViews.WorkView, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    sketchConstraintBuilder1.ConstraintType = NXOpen.SketchConstraintBuilder.Constraint.PointOnCurve
    
    nXObject19 = sketchConstraintBuilder1.Commit()
    
    objects5 = sketchConstraintBuilder1.GetCommittedObjects()
    
    sketchConstraintBuilder1.Destroy()
    
    scaleAboutPoint186 = NXOpen.Point3d(-1.2955791317350627, 1.8228497086041242, 0.0)
    viewCenter186 = NXOpen.Point3d(1.2955791317352157, -1.8228497086040585, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint186, viewCenter186)
    
    scaleAboutPoint187 = NXOpen.Point3d(-1.0364633053880354, 1.4582797668833045, 0.0)
    viewCenter187 = NXOpen.Point3d(1.0364633053881878, -1.4582797668832412, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint187, viewCenter187)
    
    scaleAboutPoint188 = NXOpen.Point3d(-0.82917064431041321, 1.1666238135066511, 0.0)
    viewCenter188 = NXOpen.Point3d(0.8291706443105662, -1.1666238135065881, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint188, viewCenter188)
    
    scaleAboutPoint189 = NXOpen.Point3d(-0.66333651544831496, 0.93329905080532771, 0.0)
    viewCenter189 = NXOpen.Point3d(0.66333651544846794, -0.93329905080526343, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint189, viewCenter189)
    
    scaleAboutPoint190 = NXOpen.Point3d(-0.82917064431041321, 1.1666238135066511, 0.0)
    viewCenter190 = NXOpen.Point3d(0.8291706443105662, -1.1666238135065858, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint190, viewCenter190)
    
    scaleAboutPoint191 = NXOpen.Point3d(-1.0364633053880346, 1.4582797668833065, 0.0)
    viewCenter191 = NXOpen.Point3d(1.0364633053881878, -1.4582797668832395, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint191, viewCenter191)
    
    scaleAboutPoint192 = NXOpen.Point3d(-1.2955791317350625, 1.822849708604124, 0.0)
    viewCenter192 = NXOpen.Point3d(1.2955791317352152, -1.8228497086040583, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint192, viewCenter192)
    
    scaleAboutPoint193 = NXOpen.Point3d(-1.6194739146688475, 2.2785621357551489, 0.0)
    viewCenter193 = NXOpen.Point3d(1.6194739146689989, -2.2785621357550796, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint193, viewCenter193)
    
    scaleAboutPoint194 = NXOpen.Point3d(-2.0243423933360791, 2.8482026696939235, 0.0)
    viewCenter194 = NXOpen.Point3d(2.0243423933362292, -2.84820266969386, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint194, viewCenter194)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch5 = theSession.ActiveSketch
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    scaleAboutPoint195 = NXOpen.Point3d(-18.678956378315302, 13.707943793763715, 0.0)
    viewCenter195 = NXOpen.Point3d(18.678956378315426, -13.707943793763647, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint195, viewCenter195)
    
    scaleAboutPoint196 = NXOpen.Point3d(-23.348695472894136, 17.134929742204626, 0.0)
    viewCenter196 = NXOpen.Point3d(23.348695472894278, -17.134929742204598, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint196, viewCenter196)
    
    scaleAboutPoint197 = NXOpen.Point3d(-29.185869341117687, 21.418662177755799, 0.0)
    viewCenter197 = NXOpen.Point3d(29.185869341117829, -21.418662177755728, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint197, viewCenter197)
    
    scaleAboutPoint198 = NXOpen.Point3d(-36.482336676397125, 26.773327722194725, 0.0)
    viewCenter198 = NXOpen.Point3d(36.48233667639726, -26.773327722194679, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint198, viewCenter198)
    
    scaleAboutPoint199 = NXOpen.Point3d(-46.338451826875385, 34.202190634122353, 0.0)
    viewCenter199 = NXOpen.Point3d(46.338451826875492, -34.202190634122296, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint199, viewCenter199)
    
    scaleAboutPoint200 = NXOpen.Point3d(-37.070761461500304, 27.361752507297879, 0.0)
    viewCenter200 = NXOpen.Point3d(37.070761461500439, -27.361752507297879, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint200, viewCenter200)
    
    scaleAboutPoint201 = NXOpen.Point3d(-29.65660916920023, 21.889402005838306, 0.0)
    viewCenter201 = NXOpen.Point3d(29.656609169200355, -21.889402005838306, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint201, viewCenter201)
    
    scaleAboutPoint202 = NXOpen.Point3d(-23.725287335360179, 17.511521604670641, 0.0)
    viewCenter202 = NXOpen.Point3d(23.725287335360292, -17.511521604670641, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint202, viewCenter202)
    
    scaleAboutPoint203 = NXOpen.Point3d(-18.980229868288124, 14.009217283736515, 0.0)
    viewCenter203 = NXOpen.Point3d(18.980229868288248, -14.009217283736538, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint203, viewCenter203)
    
    scaleAboutPoint204 = NXOpen.Point3d(-15.184183894630497, 11.207373826989192, 0.0)
    viewCenter204 = NXOpen.Point3d(15.184183894630605, -11.207373826989237, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint204, viewCenter204)
    
    scaleAboutPoint205 = NXOpen.Point3d(-12.147347115704386, 8.9658990615913421, 0.0)
    viewCenter205 = NXOpen.Point3d(12.147347115704502, -8.9658990615914007, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint205, viewCenter205)
    
    scaleAboutPoint206 = NXOpen.Point3d(-9.7178776925634978, 7.1727192492730731, 0.0)
    viewCenter206 = NXOpen.Point3d(9.7178776925636079, -7.1727192492731255, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint206, viewCenter206)
    
    scaleAboutPoint207 = NXOpen.Point3d(-7.7743021540507842, 5.7381753994184495, 0.0)
    viewCenter207 = NXOpen.Point3d(7.7743021540509005, -5.7381753994185054, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint207, viewCenter207)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete7 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects6 = [NXOpen.TaggedObject.Null] * 1 
    objects6[0] = sketch5
    nErrs14 = theSession.UpdateManager.AddObjectsToDeleteList(objects6)
    
    notifyOnDelete8 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id4 = theSession.NewestVisibleUndoMark
    
    nErrs15 = theSession.UpdateManager.DoUpdate(id4)
    
    theSession.DeleteUndoMark(markId108, None)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.96944409289364841
    rotMatrix7.Xy = -0.23170888451036417
    rotMatrix7.Xz = 0.080555220765500729
    rotMatrix7.Yx = -0.018943415802494618
    rotMatrix7.Yy = 0.25668695053844259
    rotMatrix7.Yz = 0.96630893425498876
    rotMatrix7.Zx = -0.24457983921686835
    rotMatrix7.Zy = -0.93830847926587735
    rotMatrix7.Zz = 0.2444542901779648
    translation7 = NXOpen.Point3d(-21.395688623634769, -0.11654685447991064, -8.5586900293491937)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 2.6801038970608211)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane11 = workPart.Planes.CreatePlane(origin13, normal11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane11
    
    expression46 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression47 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId110, "Create Sketch Dialog")
    
    scalar11 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge5 = extrude1.FindObject("EDGE * 130 * 140 {(50,-6,0)(25,-6,0)(0,-6,0) EXTRUDE(2)}")
    point25 = workPart.Points.CreatePoint(edge5, scalar11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction7 = workPart.Directions.CreateDirection(edge4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face2 = extrude1.FindObject("FACE 130 {(25,-6,1.4) EXTRUDE(2)}")
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction7, point25, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem6
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal12 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane12 = workPart.Planes.CreatePlane(origin14, normal12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom9 = [NXOpen.NXObject.Null] * 1 
    geom9[0] = face2
    plane12.SetGeometry(geom9)
    
    plane12.SetFlip(False)
    
    plane12.SetExpression(None)
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin15, normal13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression48 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression49 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane13.SynchronizeToPlane(plane12)
    
    scalar12 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point26 = workPart.Points.CreatePoint(edge5, scalar12, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane13.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom10 = [NXOpen.NXObject.Null] * 1 
    geom10[0] = face2
    plane13.SetGeometry(geom10)
    
    plane13.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane13.Evaluate()
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId111, None)
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject20 = sketchInPlaceBuilder4.Commit()
    
    sketch6 = nXObject20
    feature6 = sketch6.Feature
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs16 = theSession.UpdateManager.DoUpdate(markId113)
    
    sketch6.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId112, None)
    
    theSession.SetUndoMarkName(markId110, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression47)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point26)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression46)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane11.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression49)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression48)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    scaleAboutPoint208 = NXOpen.Point3d(8.1938676671266624, 1.1352949177343772, 0.0)
    viewCenter208 = NXOpen.Point3d(-8.1938676671265469, -1.1352949177344365, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint208, viewCenter208)
    
    scaleAboutPoint209 = NXOpen.Point3d(10.242334583908308, 1.4191186471679806, 0.0)
    viewCenter209 = NXOpen.Point3d(-10.242334583908193, -1.4191186471680364, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint209, viewCenter209)
    
    scaleAboutPoint210 = NXOpen.Point3d(12.802918229885373, 1.7738983089599758, 0.0)
    viewCenter210 = NXOpen.Point3d(-12.802918229885258, -1.7738983089600453, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint210, viewCenter210)
    
    scaleAboutPoint211 = NXOpen.Point3d(16.003647787356705, 2.4101879197825791, 0.0)
    viewCenter211 = NXOpen.Point3d(-16.003647787356588, -2.4101879197826661, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint211, viewCenter211)
    
    scaleAboutPoint212 = NXOpen.Point3d(12.802918229885375, 1.9281503358260517, 0.0)
    viewCenter212 = NXOpen.Point3d(-12.802918229885259, -1.9281503358261445, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint212, viewCenter212)
    
    scaleAboutPoint213 = NXOpen.Point3d(13.944383228694438, 1.6659218901537025, 0.0)
    viewCenter213 = NXOpen.Point3d(-13.944383228694322, -1.6659218901537953, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint213, viewCenter213)
    
    scaleAboutPoint214 = NXOpen.Point3d(12.043998257704224, 1.628901403705846, 0.0)
    viewCenter214 = NXOpen.Point3d(-12.043998257704105, -1.6289014037059351, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint214, viewCenter214)
    
    scaleAboutPoint215 = NXOpen.Point3d(10.267014908206885, 1.6190292739864176, 0.0)
    viewCenter215 = NXOpen.Point3d(-10.267014908206773, -1.6190292739865035, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint215, viewCenter215)
    
    scaleAboutPoint216 = NXOpen.Point3d(8.213611926565525, 1.2952234191891248, 0.0)
    viewCenter216 = NXOpen.Point3d(-8.2136119265654077, -1.2952234191892102, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint216, viewCenter216)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId115, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint13 = NXOpen.Point3d(2.5, -6.0, 4.0)
    endPoint13 = NXOpen.Point3d(-1.0000000000000011, -6.0, 4.0)
    line11 = workPart.Curves.CreateLine(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(-1.0000000000000011, -6.0, 4.0)
    endPoint14 = NXOpen.Point3d(-1.0000000000000011, -6.0, -2.0)
    line12 = workPart.Curves.CreateLine(startPoint14, endPoint14)
    
    startPoint15 = NXOpen.Point3d(-1.0000000000000011, -6.0, -2.0)
    endPoint15 = NXOpen.Point3d(2.5, -6.0, -2.0)
    line13 = workPart.Curves.CreateLine(startPoint15, endPoint15)
    
    startPoint16 = NXOpen.Point3d(2.5, -6.0, -2.0)
    endPoint16 = NXOpen.Point3d(2.5, -6.0, 4.0)
    line14 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line11
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_10.Geometry = line12
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line12
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line13
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = line13
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_12.Geometry = line14
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = line14
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = line11
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    geom11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom11.Geometry = line11
    geom11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreateHorizontalConstraint(geom11)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line11
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line12
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line12
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line13
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line13
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line14
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line14
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_13.Geometry = line11
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint29 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_13, conGeom2_13)
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = line11
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimObject2_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_5.Geometry = line11
    dimObject2_5.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_5.AssocValue = 0
    dimObject2_5.HelpPoint.X = 0.0
    dimObject2_5.HelpPoint.Y = 0.0
    dimObject2_5.HelpPoint.Z = 0.0
    dimObject2_5.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(0.74999999999999944, -6.0, 5.7193363306002576)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_7, dimObject2_5, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint8 = sketchDimensionalConstraint7
    dimension7 = sketchHelpedDimensionalConstraint8.AssociatedDimension
    
    expression50 = sketchHelpedDimensionalConstraint8.AssociatedExpression
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = line12
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimObject2_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_6.Geometry = line12
    dimObject2_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_6.AssocValue = 0
    dimObject2_6.HelpPoint.X = 0.0
    dimObject2_6.HelpPoint.Y = 0.0
    dimObject2_6.HelpPoint.Z = 0.0
    dimObject2_6.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(-2.7193363306002585, -6.0, 1.0)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_8, dimObject2_6, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint9 = sketchDimensionalConstraint8
    dimension8 = sketchHelpedDimensionalConstraint9.AssociatedDimension
    
    expression51 = sketchHelpedDimensionalConstraint9.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line11
    geoms8[1] = line12
    geoms8[2] = line13
    geoms8[3] = line14
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms8)
    
    geoms9 = [NXOpen.SmartObject.Null] * 4 
    geoms9[0] = line11
    geoms9[1] = line12
    geoms9[2] = line13
    geoms9[3] = line14
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms9)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Sketch Constraints->Point on Curve
    # ----------------------------------------------
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraints")
    
    sketchConstraintBuilder2 = workPart.Sketches.CreateConstraintBuilder()
    
    edge6 = extrude1.FindObject("EDGE * 130 * 150 {(0,-6,0)(0,-6,1.4)(0,-6,2.8) EXTRUDE(2)}")
    point1_45 = NXOpen.Point3d(4.4249030572965853e-17, -6.0, 1.3999999999999968)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    added4 = sketchConstraintBuilder2.GeometryToConstrain.Add(NXOpen.InferSnapType.SnapType.Mid, edge6, workPart.ModelingViews.WorkView, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    point1_46 = NXOpen.Point3d(-1.0000000000000009, -6.0, 0.24395266552917794)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchConstraintBuilder2.GeometryToConstrainTo.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line12, workPart.ModelingViews.WorkView, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    sketchConstraintBuilder2.ConstraintType = NXOpen.SketchConstraintBuilder.Constraint.PointOnCurve
    
    nXObject21 = sketchConstraintBuilder2.Commit()
    
    objects7 = sketchConstraintBuilder2.GetCommittedObjects()
    
    sketchConstraintBuilder2.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder10 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines53 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines53)
    
    lines54 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines54)
    
    lines55 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines55)
    
    lines56 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines56)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines57 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines57)
    
    lines58 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines58)
    
    lines59 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines59)
    
    lines60 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines60)
    
    theSession.SetUndoMarkName(markId117, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder10.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits349 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits350 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits351 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits352 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits353 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits354 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits355 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits356 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits357 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits358 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits359 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits360 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits361 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits362 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits363 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits364 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits365 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits366 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits367 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits368 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    point1_47 = NXOpen.Point3d(3.5000000000000009, -6.0, 3.9999999999999996)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, workPart.ModelingViews.WorkView, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    point1_48 = NXOpen.Point3d(-1.3322676295501878e-15, -6.0, 4.0)
    point2_48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, workPart.ModelingViews.WorkView, point1_48, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_48)
    
    point1_49 = NXOpen.Point3d(3.5000000000000009, -6.0, 3.9999999999999996)
    point2_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, workPart.ModelingViews.WorkView, point1_49, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_49)
    
    point1_50 = NXOpen.Point3d(-1.3322676295501878e-15, -6.0, 4.0)
    point2_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, workPart.ModelingViews.WorkView, point1_50, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_50)
    
    dimensionlinearunits369 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits370 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits371 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits372 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits373 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits374 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin6 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin6.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin6.View = NXOpen.View.Null
    assocOrigin6.ViewOfGeometry = workPart.ModelingViews.WorkView
    point27 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin6.PointOnGeometry = point27
    assocOrigin6.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.DimensionLine = 0
    assocOrigin6.AssociatedView = NXOpen.View.Null
    assocOrigin6.AssociatedPoint = NXOpen.Point.Null
    assocOrigin6.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.XOffsetFactor = 0.0
    assocOrigin6.YOffsetFactor = 0.0
    assocOrigin6.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder10.Origin.SetAssociativeOrigin(assocOrigin6)
    
    point28 = NXOpen.Point3d(1.8918949394315598, -6.0, 8.3059286796042038)
    sketchRapidDimensionBuilder10.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point28)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.TextCentered = True
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject22 = sketchRapidDimensionBuilder10.Commit()
    
    theSession.DeleteUndoMark(markId118, None)
    
    theSession.SetUndoMarkName(markId117, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId117, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder10.Destroy()
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder11 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines61 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines61)
    
    lines62 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines62)
    
    lines63 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines63)
    
    lines64 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines64)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId119, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder11.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits375 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits376 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits377 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits378 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits379 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits380 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits381 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits382 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits383 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits384 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits385 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits386 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits387 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits388 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits389 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits390 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits391 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits392 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits393 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits394 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    expression52 = workPart.Expressions.FindObject("p9")
    expression52.SetFormula("8")
    
    theSession.SetUndoMarkVisibility(markId119, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId120, None)
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId119, "Edit Driving Value")
    
    point29 = NXOpen.Point3d(6.2893364016542996, -6.0, 4.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(line11, workPart.ModelingViews.WorkView, point29)
    
    point1_51 = NXOpen.Point3d(7.9999999999999991, -6.0, 4.0)
    point2_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, workPart.ModelingViews.WorkView, point1_51, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_51)
    
    point1_52 = NXOpen.Point3d(-8.8817841970012523e-16, -6.0, 4.0)
    point2_52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line11, workPart.ModelingViews.WorkView, point1_52, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_52)
    
    dimensionlinearunits395 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits396 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits397 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits398 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits399 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits400 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    point1_53 = NXOpen.Point3d(8.8498061145931694e-17, -6.0, 2.7999999999999936)
    point2_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge4, workPart.ModelingViews.WorkView, point1_53, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_53)
    
    point1_54 = NXOpen.Point3d(6.2893364016542996, -6.0, 4.0)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line11, workPart.ModelingViews.WorkView, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    point1_55 = NXOpen.Point3d(8.8498061145931694e-17, -6.0, 2.7999999999999936)
    point2_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge4, workPart.ModelingViews.WorkView, point1_55, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_55)
    
    point1_56 = NXOpen.Point3d(6.2893364016542996, -6.0, 4.0)
    point2_56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line11, workPart.ModelingViews.WorkView, point1_56, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_56)
    
    point1_57 = NXOpen.Point3d(8.8498061145931694e-17, -6.0, 2.7999999999999936)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge4, workPart.ModelingViews.WorkView, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    dimensionlinearunits401 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits402 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits403 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits404 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits405 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits406 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits407 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits408 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits409 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits410 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits411 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits412 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin7 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin7.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin7.View = NXOpen.View.Null
    assocOrigin7.ViewOfGeometry = workPart.ModelingViews.WorkView
    point30 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin7.PointOnGeometry = point30
    assocOrigin7.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.DimensionLine = 0
    assocOrigin7.AssociatedView = NXOpen.View.Null
    assocOrigin7.AssociatedPoint = NXOpen.Point.Null
    assocOrigin7.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.XOffsetFactor = 0.0
    assocOrigin7.YOffsetFactor = 0.0
    assocOrigin7.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder11.Origin.SetAssociativeOrigin(assocOrigin7)
    
    point31 = NXOpen.Point3d(12.506408813762313, -6.0, 6.3852071213919723)
    sketchRapidDimensionBuilder11.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point31)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.TextCentered = False
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject23 = sketchRapidDimensionBuilder11.Commit()
    
    theSession.DeleteUndoMark(markId122, None)
    
    theSession.SetUndoMarkName(markId121, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId121, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder11.Destroy()
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder12 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines65 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines65)
    
    lines66 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines66)
    
    lines67 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines67)
    
    lines68 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines68)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId123, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder12.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits413 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits414 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits415 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits416 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits417 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits418 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits419 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits420 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits421 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits422 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits423 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits424 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits425 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits426 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits427 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits428 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits429 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits430 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits431 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits432 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    expression53 = workPart.Expressions.FindObject("p10")
    expression53.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId123, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId124, None)
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId123, "Edit Driving Value")
    
    point32 = NXOpen.Point3d(5.7838833600195025, -6.0, -1.7000000000000035)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(line13, workPart.ModelingViews.WorkView, point32)
    
    point1_58 = NXOpen.Point3d(8.0000000000000018, -6.0, -1.7000000000000028)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line13, workPart.ModelingViews.WorkView, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    point1_59 = NXOpen.Point3d(1.3322676295501878e-15, -6.0, -1.7000000000000055)
    point2_59 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line13, workPart.ModelingViews.WorkView, point1_59, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_59)
    
    dimensionlinearunits433 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits434 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits435 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits436 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits437 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits438 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    point1_60 = NXOpen.Point3d(0.0, -6.0, 0.0)
    point2_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge5, workPart.ModelingViews.WorkView, point1_60, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_60)
    
    point1_61 = NXOpen.Point3d(5.7838833600195025, -6.0, -1.7000000000000035)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line13, workPart.ModelingViews.WorkView, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    point1_62 = NXOpen.Point3d(0.0, -6.0, 0.0)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge5, workPart.ModelingViews.WorkView, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    point1_63 = NXOpen.Point3d(5.7838833600195025, -6.0, -1.7000000000000035)
    point2_63 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line13, workPart.ModelingViews.WorkView, point1_63, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_63)
    
    point1_64 = NXOpen.Point3d(0.0, -6.0, 0.0)
    point2_64 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge5, workPart.ModelingViews.WorkView, point1_64, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_64)
    
    dimensionlinearunits439 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits440 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits441 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits442 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits443 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits444 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits445 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits446 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits447 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits448 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits449 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits450 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin8 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin8.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin8.View = NXOpen.View.Null
    assocOrigin8.ViewOfGeometry = workPart.ModelingViews.WorkView
    point33 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin8.PointOnGeometry = point33
    assocOrigin8.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.DimensionLine = 0
    assocOrigin8.AssociatedView = NXOpen.View.Null
    assocOrigin8.AssociatedPoint = NXOpen.Point.Null
    assocOrigin8.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.XOffsetFactor = 0.0
    assocOrigin8.YOffsetFactor = 0.0
    assocOrigin8.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder12.Origin.SetAssociativeOrigin(assocOrigin8)
    
    point34 = NXOpen.Point3d(9.4736905639535252, -6.0, -3.6733084071405058)
    sketchRapidDimensionBuilder12.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point34)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.TextCentered = False
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject24 = sketchRapidDimensionBuilder12.Commit()
    
    theSession.DeleteUndoMark(markId126, None)
    
    theSession.SetUndoMarkName(markId125, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId125, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder12.Destroy()
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder13 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines69 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines69)
    
    lines70 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines70)
    
    lines71 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines71)
    
    lines72 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines72)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId127, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder13.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits451 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits452 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits453 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits454 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits455 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits456 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits457 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits458 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits459 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits460 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder13.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits461 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits462 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits463 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits464 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits465 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits466 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits467 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits468 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits469 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits470 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    expression54 = workPart.Expressions.FindObject("p11")
    expression54.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId127, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId128, None)
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId127, "Edit Driving Value")
    
    sketchRapidDimensionBuilder13.Destroy()
    
    theSession.UndoToMark(markId129, None)
    
    theSession.DeleteUndoMark(markId129, None)
    
    sketchRapidDimensionBuilder13.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch7 = theSession.ActiveSketch
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression55 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("7.8")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies24)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId131, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.69993014841512424
    rotMatrix8.Xy = 0.65464470185954504
    rotMatrix8.Xz = 0.28554877283366653
    rotMatrix8.Yx = -0.594046311663738
    rotMatrix8.Yy = 0.31166026356742493
    rotMatrix8.Yz = 0.74160424736634023
    rotMatrix8.Zx = 0.39649308561221464
    rotMatrix8.Zy = -0.68870036622635467
    rotMatrix8.Zz = 0.60702968512371314
    translation8 = NXOpen.Point3d(-12.28577022545737, 14.740532042782229, -24.344294363881755)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 2.6801038970608206)
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features3 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature3 = feature6
    features3[0] = sketchFeature3
    curveFeatureRule3 = workPart.ScRuleFactory.CreateRuleCurveFeature(features3)
    
    section4.AllowSelfIntersection(True)
    
    rules4 = [None] * 1 
    rules4[0] = curveFeatureRule3
    helpPoint4 = NXOpen.Point3d(0.82311134448525536, -6.0000000000000266, 4.300000000000006)
    section4.AddToSection(rules4, line11, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId133, None)
    
    direction8 = workPart.Directions.CreateDirection(sketch7, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction8
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies26)
    
    expression56 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId132, None)
    
    direction9 = extrudeBuilder4.Direction
    
    success2 = direction9.ReverseDirection()
    
    extrudeBuilder4.Direction = direction9
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies27)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies28)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies29)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies30 = [NXOpen.Body.Null] * 1 
    targetBodies30[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies30)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("27")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies31 = [NXOpen.Body.Null] * 1 
    targetBodies31[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies31)
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies32 = [NXOpen.Body.Null] * 1 
    targetBodies32[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies32)
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId134, None)
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    feature7 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId135, None)
    
    theSession.SetUndoMarkName(markId131, "Extrude")
    
    expression57 = extrudeBuilder4.Limits.StartExtend.Value
    expression58 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression55)
    
    workPart.Expressions.Delete(expression56)
    
    # ----------------------------------------------
    #   Menu: Edit->Feature->Edit Parameters...
    # ----------------------------------------------
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Feature Parameters")
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    extrude2 = feature7
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(extrude2)
    
    section4.PrepareMappingData()
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    targetBodies33 = [NXOpen.Body.Null] * 1 
    targetBodies33[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies33)
    
    targetBodies34 = [NXOpen.Body.Null] * 1 
    targetBodies34[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies34)
    
    expression59 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    expression60 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.SetUndoMarkName(markId137, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies35 = [NXOpen.Body.Null] * 1 
    targetBodies35[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies35)
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId138, None)
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    feature8 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId139, None)
    
    theSession.SetUndoMarkName(markId137, "Extrude")
    
    section4.CleanMappingData()
    
    expression61 = extrudeBuilder5.Limits.StartExtend.Value
    expression62 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression59)
    
    workPart.Expressions.Delete(expression60)
    
    theSession.DeleteUndoMark(markId137, None)
    
    theSession.Preferences.Modeling.UpdatePending = False
    
    nErrs17 = theSession.UpdateManager.DoUpdate(markId136)
    
    theSession.Preferences.Modeling.UpdatePending = False
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.52643372132544763
    rotMatrix9.Xy = 0.84936262532861495
    rotMatrix9.Xz = -0.038087632458948993
    rotMatrix9.Yx = -0.36395647095481148
    rotMatrix9.Yy = 0.2656125034634314
    rotMatrix9.Yz = 0.89274054755791876
    rotMatrix9.Zx = 0.7683770066195138
    rotMatrix9.Zy = -0.45610648833224965
    rotMatrix9.Zz = 0.44895840230433881
    translation9 = NXOpen.Point3d(-6.9111148103985851, 8.6385519244788718, -32.722310959434822)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 2.6801038970608206)
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects8 = [NXOpen.DisplayableObject.Null] * 5 
    objects8[0] = sketch7
    objects8[1] = line11
    objects8[2] = line12
    objects8[3] = line13
    objects8[4] = line14
    theSession.DisplayManager.BlankObjects(objects8)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = 0.62286334790137599
    rotMatrix10.Xy = 0.77739867954977127
    rotMatrix10.Xz = -0.087707142670149077
    rotMatrix10.Yx = -0.3969253377020841
    rotMatrix10.Yy = 0.41063425295962613
    rotMatrix10.Yz = 0.82087135812280387
    rotMatrix10.Zx = 0.67415986689447494
    rotMatrix10.Zy = -0.47647749509348508
    rotMatrix10.Zz = 0.56433825897086021
    translation10 = NXOpen.Point3d(-9.4682799978376462, 9.9984557068584348, -30.589527285925676)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 2.6801038970608206)
    
    scaleAboutPoint217 = NXOpen.Point3d(-9.5759658278466979, -1.4314588093173317, 0.0)
    viewCenter217 = NXOpen.Point3d(9.5759658278468116, 1.4314588093172724, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint217, viewCenter217)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 0.86038117642721779
    rotMatrix11.Xy = 0.37642242457088221
    rotMatrix11.Xz = 0.34358461771432569
    rotMatrix11.Yx = -0.23391753542831145
    rotMatrix11.Yy = -0.30728925308046934
    rotMatrix11.Yz = 0.92241850673129766
    rotMatrix11.Zx = 0.45279887132022101
    rotMatrix11.Zy = -0.87400198696652298
    rotMatrix11.Zz = -0.1763340832332437
    translation11 = NXOpen.Point3d(-15.297769774889268, 3.9136158857054051, -25.211134593102713)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 3.3501298713260259)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal14 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane14 = workPart.Planes.CreatePlane(origin16, normal14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane14
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId141, "Create Sketch Dialog")
    
    scalar13 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point35 = workPart.Points.CreatePoint(edge4, scalar13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction10 = workPart.Directions.CreateDirection(edge4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform7 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction10, point35, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem7
    
    origin17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal15 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane15 = workPart.Planes.CreatePlane(origin17, normal15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane15.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom12 = [NXOpen.NXObject.Null] * 1 
    geom12[0] = face2
    plane15.SetGeometry(geom12)
    
    plane15.SetFlip(False)
    
    plane15.SetExpression(None)
    
    plane15.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane15.Evaluate()
    
    origin18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal16 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin18, normal16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression65 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression66 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane16.SynchronizeToPlane(plane15)
    
    scalar14 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point36 = workPart.Points.CreatePoint(edge4, scalar14, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane16.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom13 = [NXOpen.NXObject.Null] * 1 
    geom13[0] = face2
    plane16.SetGeometry(geom13)
    
    plane16.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane16.Evaluate()
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId142, None)
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject25 = sketchInPlaceBuilder5.Commit()
    
    sketch8 = nXObject25
    feature9 = sketch8.Feature
    
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs18 = theSession.UpdateManager.DoUpdate(markId144)
    
    sketch8.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId143, None)
    
    theSession.SetUndoMarkName(markId141, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression64)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point36)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression63)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane14.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression66)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression65)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane16.DestroyPlane()
    
    scaleAboutPoint218 = NXOpen.Point3d(7.2658874735002748, 1.145167047453806, 0.0)
    viewCenter218 = NXOpen.Point3d(-7.265887473500162, -1.1451670474538653, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint218, viewCenter218)
    
    scaleAboutPoint219 = NXOpen.Point3d(9.0823593418753266, 1.4314588093172647, 0.0)
    viewCenter219 = NXOpen.Point3d(-9.0823593418752111, -1.4314588093173166, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint219, viewCenter219)
    
    scaleAboutPoint220 = NXOpen.Point3d(7.7743021540508979, -1.1723154041822961, 0.0)
    viewCenter220 = NXOpen.Point3d(-7.7743021540507815, 1.1723154041822403, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint220, viewCenter220)
    
    scaleAboutPoint221 = NXOpen.Point3d(6.2194417232407284, -0.93785232334584412, 0.0)
    viewCenter221 = NXOpen.Point3d(-6.219441723240613, 0.93785232334578472, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint221, viewCenter221)
    
    scaleAboutPoint222 = NXOpen.Point3d(4.6596452275708424, -0.27641963214405513, 0.0)
    viewCenter222 = NXOpen.Point3d(-4.6596452275707358, 0.27641963214400173, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint222, viewCenter222)
    
    scaleAboutPoint223 = NXOpen.Point3d(2.2745386873566411, 0.28431733591954361, 0.0)
    viewCenter223 = NXOpen.Point3d(-2.2745386873565341, -0.28431733591960062, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint223, viewCenter223)
    
    scaleAboutPoint224 = NXOpen.Point3d(1.819630949885322, 0.22745386873562726, 0.0)
    viewCenter224 = NXOpen.Point3d(-1.8196309498852195, -0.22745386873568804, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint224, viewCenter224)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint225 = NXOpen.Point3d(-5.0949666596787084, 1.2535235432542708, 0.0)
    viewCenter225 = NXOpen.Point3d(5.0949666596788079, -1.2535235432543277, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint225, viewCenter225)
    
    scaleAboutPoint226 = NXOpen.Point3d(-4.0759733277429566, 1.0028188346034117, 0.0)
    viewCenter226 = NXOpen.Point3d(4.0759733277430552, -1.0028188346034683, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint226, viewCenter226)
    
    scaleAboutPoint227 = NXOpen.Point3d(-5.4184566063249786, 0.48523491996937884, 0.0)
    viewCenter227 = NXOpen.Point3d(5.418456606325079, -0.4852349199694358, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint227, viewCenter227)
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId146, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint17 = NXOpen.Point3d(-1.5, -6.0, 2.7999999999999945)
    endPoint17 = NXOpen.Point3d(6.9999999999999991, -6.0, 2.7999999999999945)
    line15 = workPart.Curves.CreateLine(startPoint17, endPoint17)
    
    startPoint18 = NXOpen.Point3d(6.9999999999999991, -6.0, 2.7999999999999945)
    endPoint18 = NXOpen.Point3d(6.9999999999999991, -6.0, 0.29999999999999449)
    line16 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    startPoint19 = NXOpen.Point3d(6.9999999999999991, -6.0, 0.29999999999999449)
    endPoint19 = NXOpen.Point3d(-1.5, -6.0, 0.29999999999999449)
    line17 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    startPoint20 = NXOpen.Point3d(-1.5, -6.0, 0.29999999999999449)
    endPoint20 = NXOpen.Point3d(-1.5, -6.0, 2.7999999999999945)
    line18 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line17, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line18, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = line15
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_14.SplineDefiningPointIndex = 0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_14.Geometry = line16
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint30 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_14, geom2_14)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = line16
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_15.SplineDefiningPointIndex = 0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_15.Geometry = line17
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint31 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_15, geom2_15)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = line17
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_16.SplineDefiningPointIndex = 0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_16.Geometry = line18
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint32 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_16, geom2_16)
    
    geom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_17.Geometry = line18
    geom1_17.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_17.SplineDefiningPointIndex = 0
    geom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_17.Geometry = line15
    geom2_17.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint33 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_17, geom2_17)
    
    geom14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom14.Geometry = line15
    geom14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint34 = theSession.ActiveSketch.CreateHorizontalConstraint(geom14)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line15
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_14.Geometry = line16
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint35 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line16
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_15.Geometry = line17
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint36 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_15, conGeom2_15)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line17
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_16.Geometry = line18
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint37 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_16, conGeom2_16)
    
    conGeom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_17.Geometry = line18
    conGeom1_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_17.SplineDefiningPointIndex = 0
    conGeom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_17.Geometry = line15
    conGeom2_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint38 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_17, conGeom2_17)
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = line15
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimObject2_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_7.Geometry = line15
    dimObject2_7.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_7.AssocValue = 0
    dimObject2_7.HelpPoint.X = 0.0
    dimObject2_7.HelpPoint.Y = 0.0
    dimObject2_7.HelpPoint.Z = 0.0
    dimObject2_7.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(2.7499999999999996, -6.0, 1.0806636693997387)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_9, dimObject2_7, dimOrigin9, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint10 = sketchDimensionalConstraint9
    dimension9 = sketchHelpedDimensionalConstraint10.AssociatedDimension
    
    expression67 = sketchHelpedDimensionalConstraint10.AssociatedExpression
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = line16
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimObject2_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_8.Geometry = line16
    dimObject2_8.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_8.AssocValue = 0
    dimObject2_8.HelpPoint.X = 0.0
    dimObject2_8.HelpPoint.Y = 0.0
    dimObject2_8.HelpPoint.Z = 0.0
    dimObject2_8.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(5.2806636693997433, -6.0, 1.5499999999999945)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_10, dimObject2_8, dimOrigin10, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint11 = sketchDimensionalConstraint10
    dimension10 = sketchHelpedDimensionalConstraint11.AssociatedDimension
    
    expression68 = sketchHelpedDimensionalConstraint11.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms10 = [NXOpen.SmartObject.Null] * 4 
    geoms10[0] = line15
    geoms10[1] = line16
    geoms10[2] = line17
    geoms10[3] = line18
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms10)
    
    geoms11 = [NXOpen.SmartObject.Null] * 4 
    geoms11[0] = line15
    geoms11[1] = line16
    geoms11[2] = line17
    geoms11[3] = line18
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms11)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder14 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines73 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBefore(lines73)
    
    lines74 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAfter(lines74)
    
    lines75 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAbove(lines75)
    
    lines76 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBelow(lines76)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder14.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines77 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBefore(lines77)
    
    lines78 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAfter(lines78)
    
    lines79 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAbove(lines79)
    
    lines80 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBelow(lines80)
    
    theSession.SetUndoMarkName(markId147, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder14.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits471 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits472 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits473 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits474 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits475 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits476 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits477 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits478 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits479 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits480 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder14.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits481 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits482 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits483 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits484 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits485 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits486 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits487 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits488 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits489 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits490 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    datumAxis2 = workPart.Datums.FindObject("DATUM_CSYS(0) Z axis")
    point37 = NXOpen.Point3d(0.0, 0.0, 2.0639340081192952)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(datumAxis2, workPart.ModelingViews.WorkView, point37)
    
    point1_65 = NXOpen.Point3d(-1.5, -6.0, 1.5499999999999945)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line18, workPart.ModelingViews.WorkView, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    dimensionlinearunits491 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits492 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits493 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits494 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits495 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits496 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin9 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin9.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin9.View = NXOpen.View.Null
    assocOrigin9.ViewOfGeometry = workPart.ModelingViews.WorkView
    point38 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin9.PointOnGeometry = point38
    assocOrigin9.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.DimensionLine = 0
    assocOrigin9.AssociatedView = NXOpen.View.Null
    assocOrigin9.AssociatedPoint = NXOpen.Point.Null
    assocOrigin9.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.XOffsetFactor = 0.0
    assocOrigin9.YOffsetFactor = 0.0
    assocOrigin9.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder14.Origin.SetAssociativeOrigin(assocOrigin9)
    
    point39 = NXOpen.Point3d(-0.34254194070116206, -6.0, 7.5733721619385861)
    sketchRapidDimensionBuilder14.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point39)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.TextCentered = False
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject26 = sketchRapidDimensionBuilder14.Commit()
    
    theSession.DeleteUndoMark(markId148, None)
    
    theSession.SetUndoMarkName(markId147, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId147, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder14.Destroy()
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder15 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines81 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBefore(lines81)
    
    lines82 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAfter(lines82)
    
    lines83 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAbove(lines83)
    
    lines84 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBelow(lines84)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder15.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId149, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder15.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits497 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits498 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits499 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits500 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits501 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits502 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits503 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits504 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits505 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits506 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder15.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits507 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits508 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits509 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits510 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits511 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits512 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits513 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits514 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits515 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits516 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    expression69 = workPart.Expressions.FindObject("p14")
    expression69.SetFormula("1")
    
    theSession.SetUndoMarkVisibility(markId149, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId150, None)
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId149, "Edit Driving Value")
    
    point40 = NXOpen.Point3d(5.1163509089546508, -6.0, 0.29999999999999649)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(line17, workPart.ModelingViews.WorkView, point40)
    
    point1_66 = NXOpen.Point3d(7.4999999999999982, -6.0, 0.29999999999999449)
    point2_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line17, workPart.ModelingViews.WorkView, point1_66, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_66)
    
    point1_67 = NXOpen.Point3d(-1.0000000000000018, -6.0, 0.3000000000000016)
    point2_67 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line17, workPart.ModelingViews.WorkView, point1_67, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_67)
    
    dimensionlinearunits517 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits518 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits519 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits520 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits521 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits522 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    extrude3 = feature8
    edge7 = extrude3.FindObject("EDGE * 160 EXTRUDE(2) 130 {(8,-6,-1.5)(4,-6,-1.5)(0,-6,-1.5) EXTRUDE(2)}")
    point1_68 = NXOpen.Point3d(4.0, -6.0, -1.4999999999999984)
    point2_68 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge7, workPart.ModelingViews.WorkView, point1_68, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_68)
    
    point1_69 = NXOpen.Point3d(5.1163509089546508, -6.0, 0.29999999999999649)
    point2_69 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line17, workPart.ModelingViews.WorkView, point1_69, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_69)
    
    point1_70 = NXOpen.Point3d(4.0, -6.0, -1.4999999999999984)
    point2_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge7, workPart.ModelingViews.WorkView, point1_70, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_70)
    
    point1_71 = NXOpen.Point3d(5.1163509089546508, -6.0, 0.29999999999999649)
    point2_71 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line17, workPart.ModelingViews.WorkView, point1_71, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_71)
    
    point1_72 = NXOpen.Point3d(4.0, -6.0, -1.4999999999999984)
    point2_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge7, workPart.ModelingViews.WorkView, point1_72, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_72)
    
    dimensionlinearunits523 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits524 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits525 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits526 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits527 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits528 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits529 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits530 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits531 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits532 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits533 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits534 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin10 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin10.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin10.View = NXOpen.View.Null
    assocOrigin10.ViewOfGeometry = workPart.ModelingViews.WorkView
    point41 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin10.PointOnGeometry = point41
    assocOrigin10.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.DimensionLine = 0
    assocOrigin10.AssociatedView = NXOpen.View.Null
    assocOrigin10.AssociatedPoint = NXOpen.Point.Null
    assocOrigin10.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.XOffsetFactor = 0.0
    assocOrigin10.YOffsetFactor = 0.0
    assocOrigin10.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder15.Origin.SetAssociativeOrigin(assocOrigin10)
    
    point42 = NXOpen.Point3d(10.322517237793065, -6.0, -2.434598062430402)
    sketchRapidDimensionBuilder15.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point42)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.TextCentered = False
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject27 = sketchRapidDimensionBuilder15.Commit()
    
    theSession.DeleteUndoMark(markId152, None)
    
    theSession.SetUndoMarkName(markId151, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId151, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder15.Destroy()
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder16 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines85 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBefore(lines85)
    
    lines86 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAfter(lines86)
    
    lines87 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAbove(lines87)
    
    lines88 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBelow(lines88)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder16.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId153, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder16.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits535 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits536 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits537 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits538 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits539 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits540 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits541 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits542 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits543 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits544 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder16.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits545 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits546 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits547 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits548 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits549 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits550 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits551 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits552 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits553 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits554 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    expression70 = workPart.Expressions.FindObject("p15")
    expression70.SetFormula("1")
    
    theSession.SetUndoMarkVisibility(markId153, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId154, None)
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId153, "Edit Driving Value")
    
    point43 = NXOpen.Point3d(4.3581713465024556, -6.0, 2.0000000000000009)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(line15, workPart.ModelingViews.WorkView, point43)
    
    point1_73 = NXOpen.Point3d(7.5, -6.0, 1.9999999999999998)
    point2_73 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line15, workPart.ModelingViews.WorkView, point1_73, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_73)
    
    point1_74 = NXOpen.Point3d(-1.0, -6.0, 2.0000000000000027)
    point2_74 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, workPart.ModelingViews.WorkView, point1_74, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_74)
    
    dimensionlinearunits555 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits556 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits557 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits558 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits559 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits560 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits561 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits562 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits563 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits564 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits565 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits566 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Destroy()
    
    theSession.UndoToMark(markId155, None)
    
    theSession.DeleteUndoMark(markId155, None)
    
    sketchRapidDimensionBuilder16.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder17 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines89 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines89)
    
    lines90 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines90)
    
    lines91 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines91)
    
    lines92 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines92)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder17.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines93 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines93)
    
    lines94 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines94)
    
    lines95 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines95)
    
    lines96 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines96)
    
    theSession.SetUndoMarkName(markId156, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder17.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits567 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits568 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits569 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits570 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits571 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits572 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits573 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits574 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits575 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits576 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder17.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits577 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits578 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits579 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits580 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits581 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits582 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits583 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits584 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits585 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits586 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    sketchRapidDimensionBuilder17.Destroy()
    
    theSession.UndoToMark(markId156, None)
    
    theSession.DeleteUndoMark(markId156, None)
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder18 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines97 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines97)
    
    lines98 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines98)
    
    lines99 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines99)
    
    lines100 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines100)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder18.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines101 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines101)
    
    lines102 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines102)
    
    lines103 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines103)
    
    lines104 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines104)
    
    theSession.SetUndoMarkName(markId157, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder18.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits587 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits588 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits589 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits590 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits591 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits592 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits593 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits594 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits595 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits596 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder18.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits597 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits598 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits599 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits600 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits601 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits602 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits603 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits604 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits605 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits606 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    edge8 = extrude3.FindObject("EDGE * 140 EXTRUDE(2) 130 {(-0,-6,4.3)(4,-6,4.3)(8,-6,4.3) EXTRUDE(2)}")
    point44 = NXOpen.Point3d(4.6614431714833335, -6.0, 4.2999999999999945)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(edge8, workPart.ModelingViews.WorkView, point44)
    
    point1_75 = NXOpen.Point3d(3.2500000000000004, -6.0, 2.0000000000000013)
    point2_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line15, workPart.ModelingViews.WorkView, point1_75, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_75)
    
    dimensionlinearunits607 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits608 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits609 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits610 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits611 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits612 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin11 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin11.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin11.View = NXOpen.View.Null
    assocOrigin11.ViewOfGeometry = workPart.ModelingViews.WorkView
    point45 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin11.PointOnGeometry = point45
    assocOrigin11.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.DimensionLine = 0
    assocOrigin11.AssociatedView = NXOpen.View.Null
    assocOrigin11.AssociatedPoint = NXOpen.Point.Null
    assocOrigin11.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.XOffsetFactor = 0.0
    assocOrigin11.YOffsetFactor = 0.0
    assocOrigin11.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder18.Origin.SetAssociativeOrigin(assocOrigin11)
    
    point46 = NXOpen.Point3d(10.170881325302624, -6.0, 8.4831876368812207)
    sketchRapidDimensionBuilder18.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point46)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.TextCentered = False
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject28 = sketchRapidDimensionBuilder18.Commit()
    
    theSession.DeleteUndoMark(markId158, None)
    
    theSession.SetUndoMarkName(markId157, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId157, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder18.Destroy()
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder19 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines105 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBefore(lines105)
    
    lines106 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAfter(lines106)
    
    lines107 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAbove(lines107)
    
    lines108 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBelow(lines108)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder19.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId159, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder19.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits613 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits614 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits615 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits616 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits617 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits618 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits619 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits620 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits621 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits622 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder19.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits623 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits624 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits625 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits626 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits627 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits628 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits629 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits630 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits631 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits632 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    expression71 = workPart.Expressions.FindObject("p16")
    expression71.SetFormula("1")
    
    theSession.SetUndoMarkVisibility(markId159, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId160, None)
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId159, "Edit Driving Value")
    
    sketchRapidDimensionBuilder19.Destroy()
    
    theSession.UndoToMark(markId161, None)
    
    theSession.DeleteUndoMark(markId161, None)
    
    sketchRapidDimensionBuilder19.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder20 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines109 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines109)
    
    lines110 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines110)
    
    lines111 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines111)
    
    lines112 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines112)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder20.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines113 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines113)
    
    lines114 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines114)
    
    lines115 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines115)
    
    lines116 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines116)
    
    theSession.SetUndoMarkName(markId162, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder20.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits633 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits634 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits635 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits636 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits637 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits638 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits639 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits640 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits641 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits642 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder20.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits643 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits644 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits645 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits646 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits647 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits648 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits649 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits650 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits651 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits652 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    point47 = NXOpen.Point3d(1.6792702258380263, -6.0, 3.2999999999999936)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(line15, workPart.ModelingViews.WorkView, point47)
    
    point1_76 = NXOpen.Point3d(-1.0, -6.0, 3.2999999999999927)
    point2_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line15, workPart.ModelingViews.WorkView, point1_76, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_76)
    
    point1_77 = NXOpen.Point3d(7.4999999999999964, -6.0, 3.2999999999999945)
    point2_77 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line15, workPart.ModelingViews.WorkView, point1_77, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_77)
    
    dimensionlinearunits653 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits654 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits655 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits656 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits657 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits658 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin12 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin12.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin12.View = NXOpen.View.Null
    assocOrigin12.ViewOfGeometry = workPart.ModelingViews.WorkView
    point48 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin12.PointOnGeometry = point48
    assocOrigin12.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.DimensionLine = 0
    assocOrigin12.AssociatedView = NXOpen.View.Null
    assocOrigin12.AssociatedPoint = NXOpen.Point.Null
    assocOrigin12.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.XOffsetFactor = 0.0
    assocOrigin12.YOffsetFactor = 0.0
    assocOrigin12.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder20.Origin.SetAssociativeOrigin(assocOrigin12)
    
    point49 = NXOpen.Point3d(4.813079083973772, -6.0, 9.0391859826795002)
    sketchRapidDimensionBuilder20.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point49)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.TextCentered = False
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject29 = sketchRapidDimensionBuilder20.Commit()
    
    theSession.DeleteUndoMark(markId163, None)
    
    theSession.SetUndoMarkName(markId162, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId162, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder20.Destroy()
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder21 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines117 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBefore(lines117)
    
    lines118 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAfter(lines118)
    
    lines119 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAbove(lines119)
    
    lines120 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBelow(lines120)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder21.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId164, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder21.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits659 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits660 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits661 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits662 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits663 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits664 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits665 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits666 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits667 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits668 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder21.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits669 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits670 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits671 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits672 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits673 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits674 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits675 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits676 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits677 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits678 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    expression72 = workPart.Expressions.FindObject("p17")
    expression72.SetFormula("8")
    
    theSession.SetUndoMarkVisibility(markId164, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId165, None)
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId164, "Edit Driving Value")
    
    sketchRapidDimensionBuilder21.Destroy()
    
    theSession.UndoToMark(markId166, None)
    
    theSession.DeleteUndoMark(markId166, None)
    
    sketchRapidDimensionBuilder21.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch9 = theSession.ActiveSketch
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.56156169413261303
    rotMatrix12.Xy = -0.18715577562520003
    rotMatrix12.Xz = 0.80599080598542805
    rotMatrix12.Yx = -0.56111592086982276
    rotMatrix12.Yy = -0.80202301442056934
    rotMatrix12.Yz = 0.20471445402353555
    rotMatrix12.Zx = 0.60810968338723337
    rotMatrix12.Zy = -0.56721406892801385
    rotMatrix12.Zz = -0.55540148809740075
    translation12 = NXOpen.Point3d(-10.314795722839241, 11.450560718792994, -27.565191367819171)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 3.3501298713260255)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section5
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression73 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies36 = [NXOpen.Body.Null] * 1 
    targetBodies36[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies36)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies37 = [NXOpen.Body.Null] * 1 
    targetBodies37[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies37)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId168, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features4 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature4 = feature9
    features4[0] = sketchFeature4
    curveFeatureRule4 = workPart.ScRuleFactory.CreateRuleCurveFeature(features4)
    
    section5.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = curveFeatureRule4
    helpPoint5 = NXOpen.Point3d(-1.0000000000000018, -6.0000000000000018, 1.922041640411424)
    section5.AddToSection(rules5, line18, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId170, None)
    
    direction11 = workPart.Directions.CreateDirection(sketch9, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder6.Direction = direction11
    
    targetBodies38 = [NXOpen.Body.Null] * 1 
    targetBodies38[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies38)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies39 = [NXOpen.Body.Null] * 1 
    targetBodies39[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies39)
    
    expression74 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId169, None)
    
    direction12 = extrudeBuilder6.Direction
    
    success3 = direction12.ReverseDirection()
    
    extrudeBuilder6.Direction = direction12
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies40 = [NXOpen.Body.Null] * 1 
    targetBodies40[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies40)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies41 = [NXOpen.Body.Null] * 1 
    targetBodies41[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies41)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies42 = [NXOpen.Body.Null] * 1 
    targetBodies42[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies42)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies43 = [NXOpen.Body.Null] * 1 
    targetBodies43[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies43)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies44 = [NXOpen.Body.Null] * 1 
    targetBodies44[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies44)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies45 = [NXOpen.Body.Null] * 1 
    targetBodies45[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies45)
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("13")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies46 = [NXOpen.Body.Null] * 1 
    targetBodies46[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies46)
    
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId171, None)
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder6.ParentFeatureInternal = False
    
    feature10 = extrudeBuilder6.CommitFeature()
    
    theSession.DeleteUndoMark(markId172, None)
    
    theSession.SetUndoMarkName(markId168, "Extrude")
    
    expression75 = extrudeBuilder6.Limits.StartExtend.Value
    expression76 = extrudeBuilder6.Limits.EndExtend.Value
    extrudeBuilder6.Destroy()
    
    workPart.Expressions.Delete(expression73)
    
    workPart.Expressions.Delete(expression74)
    
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects9 = [NXOpen.DisplayableObject.Null] * 5 
    objects9[0] = sketch9
    objects9[1] = line15
    objects9[2] = line16
    objects9[3] = line17
    objects9[4] = line18
    theSession.DisplayManager.BlankObjects(objects9)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = -0.017385936486248532
    rotMatrix13.Xy = 0.97244412433847738
    rotMatrix13.Xz = 0.23248689049507609
    rotMatrix13.Yx = -0.86130863548924785
    rotMatrix13.Yy = -0.13265536965522912
    rotMatrix13.Yz = 0.49045895580903176
    rotMatrix13.Zx = 0.50778456420429618
    rotMatrix13.Zy = -0.19171587816664382
    rotMatrix13.Zz = 0.83988085965489556
    translation13 = NXOpen.Point3d(8.4406002242098221, 20.563439216074944, -25.883964102814843)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 3.3501298713260255)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal17 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane17 = workPart.Planes.CreatePlane(origin19, normal17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane17
    
    expression77 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression78 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId174, "Create Sketch Dialog")
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId175, None)
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject30 = sketchInPlaceBuilder6.Commit()
    
    sketch10 = nXObject30
    feature11 = sketch10.Feature
    
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs19 = theSession.UpdateManager.DoUpdate(markId177)
    
    sketch10.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId176, None)
    
    theSession.SetUndoMarkName(markId174, "Create Sketch")
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression78)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression77)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane17.DestroyPlane()
    
    scaleAboutPoint228 = NXOpen.Point3d(4.5806681898154107, -3.7514092933832957, 0.0)
    viewCenter228 = NXOpen.Point3d(-4.5806681898152979, 3.7514092933832361, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint228, viewCenter228)
    
    scaleAboutPoint229 = NXOpen.Point3d(3.6645345518523409, -3.0011274347066412, 0.0)
    viewCenter229 = NXOpen.Point3d(-3.6645345518522245, 3.0011274347065844, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint229, viewCenter229)
    
    scaleAboutPoint230 = NXOpen.Point3d(2.9316276414818834, -2.4009019477653202, 0.0)
    viewCenter230 = NXOpen.Point3d(-2.9316276414817675, 2.4009019477652593, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint230, viewCenter230)
    
    scaleAboutPoint231 = NXOpen.Point3d(2.3048658698547331, -1.5567953682352094, 0.0)
    viewCenter231 = NXOpen.Point3d(-2.3048658698546176, 1.5567953682351485, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint231, viewCenter231)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId179, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(4.1000000000000005, -3.1000000000000001, 0.0)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 1.89660802996964, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = arc3
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(4.1000000000000005, -2.7332082494719452, 0.0)
    sketchDimensionalConstraint11 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_11, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension11 = sketchDimensionalConstraint11.AssociatedDimension
    
    expression79 = sketchDimensionalConstraint11.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder22 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines121 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBefore(lines121)
    
    lines122 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAfter(lines122)
    
    lines123 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAbove(lines123)
    
    lines124 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBelow(lines124)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder22.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines125 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBefore(lines125)
    
    lines126 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAfter(lines126)
    
    lines127 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAbove(lines127)
    
    lines128 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBelow(lines128)
    
    theSession.SetUndoMarkName(markId180, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder22.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits679 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits680 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits681 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits682 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits683 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits684 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits685 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits686 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits687 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits688 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder22.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits689 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits690 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits691 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits692 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits693 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits694 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits695 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits696 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits697 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits698 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    point1_78 = NXOpen.Point3d(4.1000000000000005, -3.1000000000000001, 0.0)
    point2_78 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_78, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_78)
    
    point1_79 = NXOpen.Point3d(4.1000000000000005, -3.1000000000000001, 0.0)
    point2_79 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_79, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_79)
    
    point1_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_80, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_80)
    
    dimensionlinearunits699 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits700 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits701 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits702 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits703 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits704 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin13 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin13.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin13.View = NXOpen.View.Null
    assocOrigin13.ViewOfGeometry = workPart.ModelingViews.WorkView
    point50 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin13.PointOnGeometry = point50
    assocOrigin13.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.DimensionLine = 0
    assocOrigin13.AssociatedView = NXOpen.View.Null
    assocOrigin13.AssociatedPoint = NXOpen.Point.Null
    assocOrigin13.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.XOffsetFactor = 0.0
    assocOrigin13.YOffsetFactor = 0.0
    assocOrigin13.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder22.Origin.SetAssociativeOrigin(assocOrigin13)
    
    point51 = NXOpen.Point3d(5.9959367063928397, 3.4219802734977476, 0.0)
    sketchRapidDimensionBuilder22.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point51)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.TextCentered = False
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject31 = sketchRapidDimensionBuilder22.Commit()
    
    theSession.DeleteUndoMark(markId181, None)
    
    theSession.SetUndoMarkName(markId180, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId180, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder22.Destroy()
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder23 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines129 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines129)
    
    lines130 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines130)
    
    lines131 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines131)
    
    lines132 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines132)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder23.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId182, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder23.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits705 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits706 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits707 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits708 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits709 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits710 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits711 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits712 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits713 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits714 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder23.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits715 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits716 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits717 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits718 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits719 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits720 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits721 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits722 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits723 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits724 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    expression80 = workPart.Expressions.FindObject("p26")
    expression80.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId182, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.79088561067819929)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId183, None)
    
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId182, "Edit Driving Value")
    
    point52 = NXOpen.Point3d(3.4727151225519304, -6.0, 4.2999999999999945)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(edge8, workPart.ModelingViews.WorkView, point52)
    
    point1_81 = NXOpen.Point3d(3.2426310037806174, -2.451745393102418, 0.0)
    point2_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_81, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_81)
    
    dimensionlinearunits725 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits726 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits727 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits728 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits729 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits730 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin14 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin14.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin14.View = NXOpen.View.Null
    assocOrigin14.ViewOfGeometry = workPart.ModelingViews.WorkView
    point53 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin14.PointOnGeometry = point53
    assocOrigin14.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.DimensionLine = 0
    assocOrigin14.AssociatedView = NXOpen.View.Null
    assocOrigin14.AssociatedPoint = NXOpen.Point.Null
    assocOrigin14.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.XOffsetFactor = 0.0
    assocOrigin14.YOffsetFactor = 0.0
    assocOrigin14.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder23.Origin.SetAssociativeOrigin(assocOrigin14)
    
    point54 = NXOpen.Point3d(-1.5413790504652605, -4.6652683926590139, 0.0)
    sketchRapidDimensionBuilder23.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point54)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.TextCentered = False
    
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject32 = sketchRapidDimensionBuilder23.Commit()
    
    theSession.DeleteUndoMark(markId185, None)
    
    theSession.SetUndoMarkName(markId184, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId184, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder23.Destroy()
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder24 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines133 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBefore(lines133)
    
    lines134 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAfter(lines134)
    
    lines135 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAbove(lines135)
    
    lines136 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBelow(lines136)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder24.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId186, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder24.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits731 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits732 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits733 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits734 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits735 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits736 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits737 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits738 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits739 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits740 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder24.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits741 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits742 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits743 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits744 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits745 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits746 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits747 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits748 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits749 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits750 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    expression81 = workPart.Expressions.FindObject("p27")
    expression81.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId186, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId187, None)
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId186, "Edit Driving Value")
    
    edge9 = extrude3.FindObject("EDGE * 140 * 150 {(8,0,4.3)(8,-3,4.3)(8,-6,4.3) EXTRUDE(2)}")
    point55 = NXOpen.Point3d(8.0, -1.6568118888486996, 4.2999999999999954)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(edge9, workPart.ModelingViews.WorkView, point55)
    
    point1_82 = NXOpen.Point3d(3.2426310037806174, -3.0000000000000018, 0.0)
    point2_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_82, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_82)
    
    dimensionlinearunits751 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits752 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits753 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits754 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits755 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits756 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin15 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin15.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin15.View = NXOpen.View.Null
    assocOrigin15.ViewOfGeometry = workPart.ModelingViews.WorkView
    point56 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin15.PointOnGeometry = point56
    assocOrigin15.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.DimensionLine = 0
    assocOrigin15.AssociatedView = NXOpen.View.Null
    assocOrigin15.AssociatedPoint = NXOpen.Point.Null
    assocOrigin15.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.XOffsetFactor = 0.0
    assocOrigin15.YOffsetFactor = 0.0
    assocOrigin15.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder24.Origin.SetAssociativeOrigin(assocOrigin15)
    
    point57 = NXOpen.Point3d(4.2814399891676072, 2.8073493748698324, 0.0)
    sketchRapidDimensionBuilder24.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point57)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.TextCentered = False
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject33 = sketchRapidDimensionBuilder24.Commit()
    
    theSession.DeleteUndoMark(markId189, None)
    
    theSession.SetUndoMarkName(markId188, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId188, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder24.Destroy()
    
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder25 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines137 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBefore(lines137)
    
    lines138 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAfter(lines138)
    
    lines139 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAbove(lines139)
    
    lines140 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBelow(lines140)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder25.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId190, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder25.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits757 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits758 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits759 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits760 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits761 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits762 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits763 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits764 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits765 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits766 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder25.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits767 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits768 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits769 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits770 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits771 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits772 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits773 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits774 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits775 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits776 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    expression82 = workPart.Expressions.FindObject("p28")
    expression82.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId190, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId191, None)
    
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId190, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketchRapidDimensionBuilder25.Destroy()
    
    theSession.UndoToMark(markId192, None)
    
    theSession.DeleteUndoMark(markId192, None)
    
    sketchRapidDimensionBuilder25.Destroy()
    
    sketch11 = theSession.ActiveSketch
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = 0.67827709439933515
    rotMatrix14.Xy = 0.6560075498501331
    rotMatrix14.Xz = 0.33105026469227206
    rotMatrix14.Yx = -0.73013786388145618
    rotMatrix14.Yy = 0.55098950500911459
    rotMatrix14.Yz = 0.40411541061488698
    rotMatrix14.Zx = 0.082697538898221304
    rotMatrix14.Zy = -0.51581455961366418
    rotMatrix14.Zz = 0.85269951163979252
    translation14 = NXOpen.Point3d(-10.038273995270885, 19.455985513144988, -16.247030627282875)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 3.3501298713260255)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section6
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression83 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies47 = [NXOpen.Body.Null] * 1 
    targetBodies47[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies47)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("13")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies48 = [NXOpen.Body.Null] * 1 
    targetBodies48[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies48)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId194, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features5 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature5 = feature11
    features5[0] = sketchFeature5
    curveFeatureRule5 = workPart.ScRuleFactory.CreateRuleCurveFeature(features5)
    
    section6.AllowSelfIntersection(True)
    
    rules6 = [None] * 1 
    rules6[0] = curveFeatureRule5
    helpPoint6 = NXOpen.Point3d(4.3772449383467116, -4.4471213799056413, 0.0)
    section6.AddToSection(rules6, arc3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId196, None)
    
    direction13 = workPart.Directions.CreateDirection(sketch11, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder7.Direction = direction13
    
    targetBodies49 = [NXOpen.Body.Null] * 1 
    targetBodies49[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies49)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies50 = [NXOpen.Body.Null] * 1 
    targetBodies50[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies50)
    
    expression84 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId195, None)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = 0.71068073578527868
    rotMatrix15.Xy = 0.0064097154573585918
    rotMatrix15.Xz = 0.70348547059015598
    rotMatrix15.Yx = -0.65261380030068072
    rotMatrix15.Yy = 0.3794473858396053
    rotMatrix15.Yz = 0.65583146389647695
    rotMatrix15.Zx = -0.26273202972001969
    rotMatrix15.Zy = -0.92519111373123708
    rotMatrix15.Zz = 0.27384901612376317
    translation15 = NXOpen.Point3d(-14.485794726078822, 15.286204505786589, -3.1606380490565629)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 3.3501298713260255)
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = True
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies51 = [NXOpen.Body.Null] * 1 
    targetBodies51[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies51)
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies52 = [NXOpen.Body.Null] * 1 
    targetBodies52[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies52)
    
    scaleAboutPoint232 = NXOpen.Point3d(-8.9244052663643423, 7.5423071056442161, 0.0)
    viewCenter232 = NXOpen.Point3d(8.924405266364456, -7.5423071056442792, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint232, viewCenter232)
    
    scaleAboutPoint233 = NXOpen.Point3d(-11.155506582955445, 9.4278838820552782, 0.0)
    viewCenter233 = NXOpen.Point3d(11.155506582955557, -9.4278838820553403, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint233, viewCenter233)
    
    scaleAboutPoint234 = NXOpen.Point3d(-14.931596200637275, 10.674240259133271, 0.0)
    viewCenter234 = NXOpen.Point3d(14.931596200637397, -10.674240259133329, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint234, viewCenter234)
    
    scaleAboutPoint235 = NXOpen.Point3d(-11.94527696050981, 8.5393922073066069, 0.0)
    viewCenter235 = NXOpen.Point3d(11.945276960509927, -8.5393922073066708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint235, viewCenter235)
    
    scaleAboutPoint236 = NXOpen.Point3d(-9.5562215684078424, 6.8315137658452798, 0.0)
    viewCenter236 = NXOpen.Point3d(9.5562215684079472, -6.831513765845342, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint236, viewCenter236)
    
    extrudeBuilder7.Limits.SymmetricOption = True
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("13")
    
    extrudeBuilder7.Limits.StartExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder7.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder7.Limits.EndExtend.Target = NXOpen.DisplayableObject.Null
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies53 = [NXOpen.Body.Null] * 1 
    targetBodies53[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies53)
    
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId197, None)
    
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder7.ParentFeatureInternal = False
    
    feature12 = extrudeBuilder7.CommitFeature()
    
    theSession.DeleteUndoMark(markId198, None)
    
    theSession.SetUndoMarkName(markId194, "Extrude")
    
    expression85 = extrudeBuilder7.Limits.EndExtend.Value
    extrudeBuilder7.Destroy()
    
    workPart.Expressions.Delete(expression83)
    
    workPart.Expressions.Delete(expression84)
    
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assign Name")
    
    extrude4 = feature12
    extrude4.SetName("Extrude")
    
    nErrs20 = theSession.UpdateManager.DoUpdate(markId199)
    
    theSession.SetUndoMarkVisibility(markId199, "Assign Name", NXOpen.Session.MarkVisibility.Visible)
    
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects10 = [NXOpen.DisplayableObject.Null] * 1 
    objects10[0] = body1
    theSession.DisplayManager.BlankObjects(objects10)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Show")
    
    objects11 = [NXOpen.DisplayableObject.Null] * 1 
    objects11[0] = body1
    theSession.DisplayManager.ShowObjects(objects11, NXOpen.DisplayManager.LayerSetting.ChangeLayerToSelectable)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.ShowOnly)
    
    # ----------------------------------------------
    #   Menu: Edit->Feature->Edit Parameters...
    # ----------------------------------------------
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Feature Parameters")
    
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(extrude4)
    
    section6.PrepareMappingData()
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    targetBodies54 = [NXOpen.Body.Null] * 1 
    targetBodies54[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies54)
    
    targetBodies55 = [NXOpen.Body.Null] * 1 
    targetBodies55[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies55)
    
    expression86 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.Limits.EndExtend.TrimType = NXOpen.GeometricUtilities.Extend.ExtendType.Symmetric
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("13")
    
    expression87 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.SetUndoMarkName(markId203, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies56 = [NXOpen.Body.Null] * 1 
    targetBodies56[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies56)
    
    markId204 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId204, None)
    
    markId205 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    feature13 = extrudeBuilder8.CommitFeature()
    
    theSession.DeleteUndoMark(markId205, None)
    
    theSession.SetUndoMarkName(markId203, "Extrude")
    
    section6.CleanMappingData()
    
    expression88 = extrudeBuilder8.Limits.EndExtend.Value
    extrudeBuilder8.Destroy()
    
    workPart.Expressions.Delete(expression86)
    
    workPart.Expressions.Delete(expression87)
    
    theSession.DeleteUndoMark(markId203, None)
    
    theSession.Preferences.Modeling.UpdatePending = False
    
    nErrs21 = theSession.UpdateManager.DoUpdate(markId202)
    
    theSession.Preferences.Modeling.UpdatePending = False
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.76039954179249014
    rotMatrix16.Xy = 0.37806344469666658
    rotMatrix16.Xz = 0.52807250319048504
    rotMatrix16.Yx = -0.64911680213222778
    rotMatrix16.Yy = 0.41615663878669273
    rotMatrix16.Yz = 0.6367582187796208
    rotMatrix16.Zx = 0.020974127667309723
    rotMatrix16.Zy = -0.82697139235759198
    rotMatrix16.Zz = 0.56185265167189746
    translation16 = NXOpen.Point3d(-12.101584550600604, 14.369128354047991, -10.361837909386249)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 4.1876623391575327)
    
    markId206 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects12 = [NXOpen.DisplayableObject.Null] * 2 
    objects12[0] = sketch11
    objects12[1] = arc3
    theSession.DisplayManager.BlankObjects(objects12)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.84961519944640596
    rotMatrix17.Xy = -0.15361552625045369
    rotMatrix17.Xz = 0.5045357102965502
    rotMatrix17.Yx = -0.52163897547288318
    rotMatrix17.Yy = -0.38580963130657059
    rotMatrix17.Yz = 0.76094921490116108
    rotMatrix17.Zx = 0.077761122273599645
    rotMatrix17.Zy = -0.90969950999540983
    rotMatrix17.Zz = -0.40792157258089012
    translation17 = NXOpen.Point3d(-15.894061394738356, 8.6024164827144265, -10.672013213503048)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 4.1876623391575327)
    
    scaleAboutPoint237 = NXOpen.Point3d(-3.222263140421783, 1.8006764608239312, 0.0)
    viewCenter237 = NXOpen.Point3d(3.2222631404218873, -1.8006764608239978, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint237, viewCenter237)
    
    scaleAboutPoint238 = NXOpen.Point3d(-2.5778105123374164, 1.4405411686591372, 0.0)
    viewCenter238 = NXOpen.Point3d(2.5778105123375212, -1.4405411686592018, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint238, viewCenter238)
    
    scaleAboutPoint239 = NXOpen.Point3d(-2.0622484098699201, 1.152432934927307, 0.0)
    viewCenter239 = NXOpen.Point3d(2.062248409870028, -1.1524329349273679, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint239, viewCenter239)
    
    scaleAboutPoint240 = NXOpen.Point3d(-1.6174497332313003, 0.72785237995407681, 0.0)
    viewCenter240 = NXOpen.Point3d(1.6174497332314048, -0.72785237995414009, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint240, viewCenter240)
    
    scaleAboutPoint241 = NXOpen.Point3d(-2.0218121665391382, 0.70763425828868542, 0.0)
    viewCenter241 = NXOpen.Point3d(2.0218121665392417, -0.70763425828874627, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint241, viewCenter241)
    
    scaleAboutPoint242 = NXOpen.Point3d(-2.5272652081739362, 0.73290691037042399, 0.0)
    viewCenter242 = NXOpen.Point3d(2.5272652081740388, -0.73290691037048472, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint242, viewCenter242)
    
    scaleAboutPoint243 = NXOpen.Point3d(-3.1590815102174332, 0.91613363796303915, 0.0)
    viewCenter243 = NXOpen.Point3d(3.1590815102175327, -0.9161336379630961, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint243, viewCenter243)
    
    scaleAboutPoint244 = NXOpen.Point3d(-3.9488518877718031, 1.1451670474538107, 0.0)
    viewCenter244 = NXOpen.Point3d(3.948851887771907, -1.1451670474538642, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint244, viewCenter244)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()